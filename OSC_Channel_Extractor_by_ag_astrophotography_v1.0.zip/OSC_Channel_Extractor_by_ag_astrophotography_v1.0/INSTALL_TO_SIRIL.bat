@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "BASE=C:\Program Files\Siril\scripts"
set "SCRIPT=OSC_Channel_Extractor_by_ag_astrophotography.py"

echo.
echo ========================================================
echo  OSC Channel Extractor by ag_astrophotography v1.0
echo  Siril Script Installer
echo ========================================================
echo.

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator rights are required.
    echo Relaunching installer as Administrator...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if not exist "%BASE%" (
    echo ERROR: Siril scripts folder was not found:
    echo %BASE%
    pause
    exit /b 1
)

copy /Y "%SCRIPT%" "%BASE%\%SCRIPT%" >nul

if errorlevel 1 (
    echo ERROR: Could not copy script.
    pause
    exit /b 1
)

echo.
echo Installed:
echo %BASE%\%SCRIPT%
echo.
echo Restart Siril and launch the script from Python Scripts.
echo.
pause
