OSC Channel Extractor by ag_astrophotography v1.0
======================================================

Target:
Siril 1.4.x / 1.4.4 Stable

INPUT
-----
One finished/debayered RGB FITS image.

FUNCTIONS
---------
Extract L
  - Siril HSL split
  - saves the L component as L_extracted.fit

Extract RGB
  - native Siril RGB split
  - saves:
      R_extracted.fit
      G_extracted.fit
      B_extracted.fit

Extract ALL
  - produces L + R + G + B

The original RGB is also copied to:
RGB_original.fit

OPEN BUTTONS
------------
Open L
Open R
Open G
Open B
Open RGB

All load the selected file directly into the currently running Siril instance.

OUTPUT
------
Extracted\
  L_extracted.fit
  R_extracted.fit
  G_extracted.fit
  B_extracted.fit
  RGB_original.fit
