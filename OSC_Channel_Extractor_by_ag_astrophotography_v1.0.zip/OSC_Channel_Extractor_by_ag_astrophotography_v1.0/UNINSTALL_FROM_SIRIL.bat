@echo off
setlocal EnableExtensions

set "BASE=C:\Program Files\Siril\scripts"
set "SCRIPT=OSC_Channel_Extractor_by_ag_astrophotography.py"

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if exist "%BASE%\%SCRIPT%" del /F /Q "%BASE%\%SCRIPT%"
echo Removed OSC Channel Extractor.
pause
