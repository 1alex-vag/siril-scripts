"""
OSC Channel Extractor by ag_astrophotography
Siril-native Python script v1.0

Target: Siril 1.4.x / 1.4.4 Stable

Features:
- native drag & drop RGB FITS
- Extract L (HSL luminance)
- Extract RGB (R/G/B)
- Extract ALL (L/R/G/B)
- Open L/R/G/B/original RGB in the running Siril instance
"""

import shutil
import tempfile
from pathlib import Path

import sirilpy as s

s.ensure_installed("PyQt6")

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QPushButton, QFileDialog,
    QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox, QLineEdit,
    QProgressBar, QPlainTextEdit, QMessageBox, QSizePolicy
)

APP_NAME = "OSC Channel Extractor by ag_astrophotography"
APP_VERSION = "1.0"

BG = "#232629"
PANEL = "#2b2f33"
PANEL2 = "#343a40"
BORDER = "#48515a"
TEXT = "#eeeeee"
SUBTEXT = "#aeb6bf"
ACCENT = "#4a90e2"

CHANNEL_COLORS = {
    "L": "#b7b7b7",
    "R": "#d84a55",
    "G": "#45b766",
    "B": "#4997da",
}


class RGBDropTile(QFrame):
    fileDropped = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.file_path = None
        self.setAcceptDrops(True)
        self.setObjectName("rgbTile")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setMinimumHeight(165)

        self.setStyleSheet("""
            QFrame#rgbTile {
                background-color: #30353a;
                border: 2px dashed #5a646e;
                border-radius: 13px;
            }
            QFrame#rgbTile:hover {
                border: 2px dashed #67aaf0;
                background-color: #353b41;
            }
            QLabel {
                background: transparent;
                border: none;
            }
            QPushButton {
                background-color: #434a51;
                color: #eeeeee;
                border: 1px solid #59636c;
                border-radius: 6px;
                padding: 7px 14px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #4a90e2;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 10)

        title = QLabel("RGB")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("Segoe UI", 25, QFont.Weight.Bold))
        title.setStyleSheet("color:#ffffff;")
        layout.addWidget(title)

        self.info = QLabel("DROP RGB FITS HERE")
        self.info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.info.setStyleSheet("color:#eeeeee;")
        layout.addWidget(self.info, 1)

        self.path_label = QLabel("or click Browse")
        self.path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.path_label.setStyleSheet("color:#aeb6bf;")
        layout.addWidget(self.path_label)

        buttons = QHBoxLayout()
        self.browse_btn = QPushButton("Browse…")
        self.clear_btn = QPushButton("Clear")
        buttons.addWidget(self.browse_btn)
        buttons.addWidget(self.clear_btn)
        layout.addLayout(buttons)

        self.browse_btn.clicked.connect(self.browse)
        self.clear_btn.clicked.connect(self.clear)

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select RGB FITS",
            "",
            "FITS images (*.fit *.fits *.fts);;All files (*.*)"
        )
        if path:
            self.set_file(path)

    def clear(self):
        self.file_path = None
        self.info.setText("DROP RGB FITS HERE")
        self.path_label.setText("or click Browse")

    def set_file(self, path):
        p = Path(path)
        self.file_path = p

        name = p.name if len(p.name) <= 40 else p.name[:37] + "..."
        self.info.setText("✓ " + name)
        self.path_label.setText(str(p.parent))
        self.fileDropped.emit(str(p))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and urls[0].isLocalFile():
                if Path(urls[0].toLocalFile()).suffix.lower() in (".fit", ".fits", ".fts"):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            p = urls[0].toLocalFile()
            if p:
                self.set_file(p)
                event.acceptProposedAction()


class App(QWidget):
    def __init__(self):
        super().__init__()

        self.siril = s.SirilInterface()
        self.siril.connect()
        self.siril.cmd("requires", "1.4.0")

        self.input_path = None
        self.results = {}

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(720, 650)
        self.setMinimumSize(650, 580)

        self.setStyleSheet("""
            QWidget {
                background-color: #232629;
                color: #eeeeee;
                font-family: "Segoe UI";
                font-size: 10pt;
            }
            QGroupBox {
                border: 1px solid #444b52;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: 600;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 5px;
            }
            QLineEdit, QPlainTextEdit {
                background-color: #2b2f33;
                border: 1px solid #444b52;
                border-radius: 5px;
                padding: 6px;
            }
            QPushButton {
                background-color: #3a4046;
                color: #eeeeee;
                border: none;
                border-radius: 6px;
                padding: 8px 12px;
            }
            QPushButton:hover {
                background-color: #4a90e2;
            }
            QPushButton:disabled {
                background-color: #2b2f33;
                color: #68717a;
            }
            QProgressBar {
                border: 1px solid #444b52;
                border-radius: 5px;
                background:#2b2f33;
                text-align:center;
            }
            QProgressBar::chunk {
                background:#4a90e2;
                border-radius:4px;
            }
        """)

        self.build_ui()

    def build_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(14, 12, 14, 12)
        main.setSpacing(8)

        title = QLabel(APP_NAME)
        title.setFont(QFont("Segoe UI", 19, QFont.Weight.Bold))
        main.addWidget(title)

        subtitle = QLabel("OSC / RGB • Extract L • Extract R/G/B • Siril-native")
        subtitle.setStyleSheet("color:#aeb6bf;")
        main.addWidget(subtitle)

        input_box = QGroupBox("1. RGB image")
        input_layout = QVBoxLayout(input_box)
        self.drop_tile = RGBDropTile()
        self.drop_tile.fileDropped.connect(self.on_file_loaded)
        input_layout.addWidget(self.drop_tile)
        main.addWidget(input_box)

        out_box = QGroupBox("2. Output")
        out_grid = QGridLayout(out_box)

        out_grid.addWidget(QLabel("Output folder"), 0, 0)
        self.output_edit = QLineEdit()
        out_grid.addWidget(self.output_edit, 0, 1)

        browse = QPushButton("Browse…")
        browse.clicked.connect(self.browse_output)
        out_grid.addWidget(browse, 0, 2)
        main.addWidget(out_box)

        extract_box = QGroupBox("3. Extract")
        extract_layout = QGridLayout(extract_box)

        self.btn_l = self.make_extract_button("Extract L", "#777777", self.extract_l)
        self.btn_rgb = self.make_extract_button("Extract RGB", "#3d6683", self.extract_rgb)
        self.btn_all = self.make_extract_button("Extract ALL", "#5b487a", self.extract_all)

        extract_layout.addWidget(self.btn_l, 0, 0)
        extract_layout.addWidget(self.btn_rgb, 0, 1)
        extract_layout.addWidget(self.btn_all, 0, 2)
        main.addWidget(extract_box)

        open_box = QGroupBox("4. Open in Siril")
        open_layout = QHBoxLayout(open_box)

        self.open_buttons = {}
        for ch in ("L", "R", "G", "B", "RGB"):
            button = QPushButton(f"Open {ch}")
            button.setEnabled(False)
            button.clicked.connect(lambda checked=False, c=ch: self.open_result(c))

            if ch in CHANNEL_COLORS:
                col = CHANNEL_COLORS[ch]
                button.setStyleSheet(f"""
                    QPushButton {{
                        background:{col};
                        color:white;
                        border-radius:6px;
                        padding:8px;
                        font-weight:600;
                    }}
                    QPushButton:disabled {{
                        background:#2b2f33;
                        color:#68717a;
                    }}
                """)

            open_layout.addWidget(button)
            self.open_buttons[ch] = button

        main.addWidget(open_box)

        status_row = QHBoxLayout()
        self.status = QLabel("Ready 😎")
        status_row.addWidget(self.status)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        status_row.addWidget(self.progress, 1)
        main.addLayout(status_row)

        log_box = QGroupBox("Processing log")
        log_layout = QVBoxLayout(log_box)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(500)
        self.log.setMinimumHeight(95)
        log_layout.addWidget(self.log)

        main.addWidget(log_box, 1)

    def make_extract_button(self, text, color, callback):
        b = QPushButton(text)
        b.setMinimumHeight(42)
        b.setStyleSheet(f"""
            QPushButton {{
                background:{color};
                color:white;
                border-radius:7px;
                padding:9px;
                font-weight:700;
            }}
            QPushButton:hover {{
                background:#4a90e2;
            }}
        """)
        b.clicked.connect(callback)
        return b

    def on_file_loaded(self, path):
        self.input_path = Path(path)
        if not self.output_edit.text().strip():
            self.output_edit.setText(str(self.input_path.parent / "Extracted"))
        self.results = {"RGB": self.input_path}
        self.update_open_buttons()

    def browse_output(self):
        folder = QFileDialog.getExistingDirectory(self, "Select output folder")
        if folder:
            self.output_edit.setText(folder)

    def write_log(self, text):
        self.log.appendPlainText(str(text))
        QApplication.processEvents()
        try:
            self.siril.log(f"[AG OSC Extractor] {text}")
        except Exception:
            pass

    def set_status(self, text, value=None):
        self.status.setText(text)
        if value is not None:
            self.progress.setValue(value)
        QApplication.processEvents()

    def cmd(self, *args):
        self.write_log("> " + " ".join(str(a) for a in args))
        self.siril.cmd(*[str(a) for a in args])

    def validate(self):
        if not self.input_path:
            raise ValueError("Load an RGB FITS first.")
        if not self.input_path.exists():
            raise FileNotFoundError(self.input_path)

        out = self.output_edit.text().strip()
        if not out:
            raise ValueError("Select an output folder.")

        out = Path(out).resolve()
        out.mkdir(parents=True, exist_ok=True)
        return out

    def prepare_workspace(self):
        work = Path(tempfile.mkdtemp(prefix="AGOSC_Extractor_"))
        src = work / "RGB.fit"
        shutil.copy2(self.input_path, src)
        return work, src

    def extract_l(self):
        self.run_extract(do_l=True, do_rgb=False)

    def extract_rgb(self):
        self.run_extract(do_l=False, do_rgb=True)

    def extract_all(self):
        self.run_extract(do_l=True, do_rgb=True)

    def run_extract(self, do_l, do_rgb):
        safe_root = None

        try:
            output = self.validate()
            self.progress.setValue(0)

            safe_root, src = self.prepare_workspace()
            self.write_log("=" * 58)
            self.write_log(f"Input: {self.input_path.name}")
            self.write_log(f"Temp workspace: {safe_root}")

            self.set_status("Loading RGB…", 15)
            self.cmd("cd", str(safe_root))
            self.cmd("load", "RGB.fit")

            # Keep an output copy of the original RGB for convenient Open RGB.
            rgb_out = output / "RGB_original.fit"
            shutil.copy2(self.input_path, rgb_out)
            self.results["RGB"] = rgb_out

            if do_rgb:
                self.set_status("Extracting R / G / B…", 40)

                # Native RGB split.
                self.cmd("split", "R", "G", "B")

                for ch in ("R", "G", "B"):
                    src_ch = safe_root / f"{ch}.fit"
                    if not src_ch.exists():
                        raise RuntimeError(f"{ch}.fit was not created by Siril.")

                    dst = output / f"{ch}_extracted.fit"
                    shutil.copy2(src_ch, dst)
                    self.results[ch] = dst
                    self.write_log(f"✓ {ch} extracted")

            if do_l:
                self.set_status("Extracting Luminance…", 68)

                # HSL split order is H, S, L. We only keep the L file.
                self.cmd("load", "RGB.fit")
                self.cmd("split", "H_temp", "S_temp", "L_temp", "-hsl")

                l_src = safe_root / "L_temp.fit"
                if not l_src.exists():
                    raise RuntimeError("HSL luminance was not created by Siril.")

                l_dst = output / "L_extracted.fit"
                shutil.copy2(l_src, l_dst)
                self.results["L"] = l_dst
                self.write_log("✓ L extracted (HSL luminance)")

            self.set_status("DONE 😎", 100)
            self.write_log(f"Output: {output}")
            self.update_open_buttons()

            QMessageBox.information(
                self,
                APP_NAME,
                f"Extraction complete 😎\n\nOutput:\n{output}"
            )

        except Exception as exc:
            self.set_status("ERROR", 0)
            self.write_log(f"ERROR: {exc}")
            QMessageBox.critical(self, APP_NAME, str(exc))

        finally:
            if safe_root:
                try:
                    self.siril.cmd("cd", str(Path.home()))
                except Exception:
                    pass
                shutil.rmtree(safe_root, ignore_errors=True)

    def update_open_buttons(self):
        for ch, btn in self.open_buttons.items():
            p = self.results.get(ch)
            btn.setEnabled(bool(p and Path(p).exists()))

    def open_result(self, channel):
        p = self.results.get(channel)
        if not p:
            return

        p = Path(p)
        if not p.exists():
            QMessageBox.critical(self, APP_NAME, f"File not found:\n{p}")
            return

        try:
            # Work around Siril 1.4 path parsing with spaces.
            cache = Path(tempfile.gettempdir()) / "AGOSC_Extractor_Open"
            cache.mkdir(parents=True, exist_ok=True)
            safe_path = cache / f"{channel}.fit"
            shutil.copy2(p, safe_path)

            self.cmd("load", str(safe_path))
            self.set_status(f"Opened {channel} in Siril")
            self.show()
            self.raise_()
            self.activateWindow()
            QApplication.processEvents()

        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, str(exc))


def main():
    app = QApplication.instance()
    owns = app is None

    if app is None:
        app = QApplication([])

    window = App()
    window.show()

    if owns:
        app.exec()


if __name__ == "__main__":
    main()
