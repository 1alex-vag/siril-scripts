"""
Astro Channel Processor by ag_astrophotography
Siril-native Python script v1.5

Author: ag_astrophotography
Target: Siril 1.4.x / 1.4.4 Stable

v0.8:
- PyQt6 GUI
- native drag & drop
- Siril-style dark theme
- colored filter tiles
- dedicated Open L / RGB / LRGB / SHO / HOO buttons
"""

import shutil
import tempfile
from pathlib import Path

import sirilpy as s

# Siril's supported way to install extra packages into its Python venv.
s.ensure_installed("PyQt6")

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QPushButton, QFileDialog, QVBoxLayout,
    QHBoxLayout, QGridLayout, QGroupBox, QComboBox, QLineEdit, QCheckBox,
    QProgressBar, QPlainTextEdit, QMessageBox, QSizePolicy
)


APP_NAME = "Astro Channel Processor by ag_astrophotography"
APP_VERSION = "1.5"
CHANNELS = ("L", "R", "G", "B", "Ha", "OIII", "SII")
REFERENCE_PRIORITY = ("L", "Ha", "R", "G", "B", "OIII", "SII")

COLORS = {
    "L":    ("#7d858c", "#e9edf0"),
    "R":    ("#7c2d35", "#ffd7db"),
    "G":    ("#285c3b", "#d8ffe5"),
    "B":    ("#294b73", "#d7eaff"),
    "Ha":   ("#69252e", "#ffd2d7"),
    "OIII": ("#17646a", "#cfffff"),
    "SII":  ("#76541f", "#ffe7ad"),
}





class DropTile(QFrame):
    fileDropped = pyqtSignal(str, str)

    def __init__(self, channel, parent=None):
        super().__init__(parent)
        self.channel = channel
        self.file_path = None
        self.setAcceptDrops(True)
        self.setMinimumSize(155, 145)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setObjectName("tile")

        # Important: force Qt to actually paint the stylesheet background.
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

        bg, fg = COLORS[channel]

        self.setStyleSheet(f"""
            QFrame#tile {{
                background-color: {bg};
                border: 2px solid rgba(255,255,255,0.18);
                border-radius: 12px;
            }}
            QFrame#tile:hover {{
                border: 2px solid rgba(255,255,255,0.48);
            }}
            QLabel {{
                background: transparent;
                border: none;
                color: {fg};
            }}
            QPushButton {{
                background-color: rgba(15,15,15,0.25);
                color: {fg};
                border: 1px solid rgba(255,255,255,0.22);
                border-radius: 6px;
                padding: 6px 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background-color: rgba(15,15,15,0.42);
                border: 1px solid rgba(255,255,255,0.42);
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 9)
        layout.setSpacing(5)

        self.title = QLabel(channel)
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        self.title.setStyleSheet(f"color:{fg}; font-weight:800;")
        layout.addWidget(self.title)

        self.info = QLabel("DROP FITS HERE")
        self.info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.info.setWordWrap(True)
        self.info.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.info.setStyleSheet(f"color:{fg};")
        layout.addWidget(self.info, 1)

        self.path_label = QLabel("or click Browse")
        self.path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.path_label.setWordWrap(True)
        self.path_label.setStyleSheet(f"color:{fg}; font-size:8pt;")
        layout.addWidget(self.path_label)

        row = QHBoxLayout()
        row.setSpacing(6)

        self.browse_btn = QPushButton("Browse…")
        self.clear_btn = QPushButton("Clear")

        row.addWidget(self.browse_btn)
        row.addWidget(self.clear_btn)
        layout.addLayout(row)

        self.browse_btn.clicked.connect(self.browse)
        self.clear_btn.clicked.connect(self.clear)

    def browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            f"Select {self.channel} FITS",
            "",
            "FITS images (*.fit *.fits *.fts);;All files (*.*)"
        )
        if path:
            self.set_file(path)

    def clear(self):
        self.file_path = None
        self.info.setText("DROP FITS HERE")
        self.path_label.setText("or click Browse")
        bg, fg = COLORS[self.channel]
        self.info.setStyleSheet(f"color:{fg};")
        self.path_label.setStyleSheet(f"color:{fg}; font-size:8pt;")

    def set_file(self, path):
        p = Path(path)
        self.file_path = p

        name = p.name if len(p.name) <= 24 else p.name[:21] + "..."
        self.info.setText("✓ " + name)
        self.path_label.setText(str(p.parent))
        self.info.setStyleSheet("color:#ffffff;")
        self.path_label.setStyleSheet("color:rgba(255,255,255,0.95); font-size:8pt;")

        self.fileDropped.emit(self.channel, str(p))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and urls[0].isLocalFile():
                suffix = Path(urls[0].toLocalFile()).suffix.lower()
                if suffix in (".fit", ".fits", ".fts"):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if path:
                self.set_file(path)
                event.acceptProposedAction()


class App(QWidget):
    def __init__(self):
        super().__init__()

        self.siril = s.SirilInterface()
        self.siril.connect()
        self.siril.cmd("requires", "1.4.0")

        self.channel_paths = {ch: None for ch in CHANNELS}
        self.results = {}

        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.resize(860, 650)
        self.setMinimumSize(800, 600)

        self.setStyleSheet("""
            QWidget {
                background-color: #232629;
                color: #e7e7e7;
                font-family: "Segoe UI";
                font-size: 10pt;
            }
            QGroupBox {
                border: 1px solid #444b52;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: 600;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 5px;
                color: #e7e7e7;
            }
            QLineEdit, QComboBox, QPlainTextEdit {
                background-color: #2b2f33;
                border: 1px solid #444b52;
                border-radius: 5px;
                padding: 6px;
                color: #eeeeee;
            }
            QPushButton {
                background-color: #3a4046;
                color: #eeeeee;
                border: none;
                border-radius: 6px;
                padding: 8px 12px;
            }
            QPushButton:hover {
                background-color: #4a90e2;
            }
            QPushButton:disabled {
                background-color: #2b2f33;
                color: #69727a;
            }
            QCheckBox {
                spacing: 7px;
            }
            QProgressBar {
                border: 1px solid #444b52;
                border-radius: 5px;
                background:#2b2f33;
                text-align:center;
            }
            QProgressBar::chunk {
                background:#4a90e2;
                border-radius:4px;
            }
        """)

        self.build_ui()

    def build_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(10, 8, 10, 8)
        main.setSpacing(6)

        title = QLabel(APP_NAME)
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        main.addWidget(title)

        subtitle = QLabel("AG Scripts • Drag & Drop • LRGB / SHO / HOO")
        subtitle.setStyleSheet("color:#aeb6bf;")
        main.addWidget(subtitle)

        # Channel tiles
        channel_box = QGroupBox("1. Channel stacks")
        channel_grid = QGridLayout(channel_box)
        channel_grid.setSpacing(6)

        positions = {
            "L": (0, 0), "R": (0, 1), "G": (0, 2), "B": (0, 3),
            "Ha": (1, 0), "OIII": (1, 1), "SII": (1, 2),
        }
        self.tiles = {}
        for ch in CHANNELS:
            tile = DropTile(ch)
            tile.fileDropped.connect(self.on_file_loaded)
            r, c = positions[ch]
            channel_grid.addWidget(tile, r, c)
            self.tiles[ch] = tile

        main.addWidget(channel_box)

        # Registration/output
        reg_box = QGroupBox("2. Registration + output")
        reg_grid = QGridLayout(reg_box)

        reg_grid.addWidget(QLabel("Output folder"), 0, 0)
        self.output_edit = QLineEdit()
        reg_grid.addWidget(self.output_edit, 0, 1)

        browse_output = QPushButton("Browse…")
        browse_output.clicked.connect(self.browse_output)
        reg_grid.addWidget(browse_output, 0, 2)

        reg_grid.addWidget(QLabel("Reference"), 1, 0)
        self.reference = QComboBox()
        self.reference.addItems(["Auto"] + list(CHANNELS))
        reg_grid.addWidget(self.reference, 1, 1)

        hint = QLabel("Auto: L → Ha → R → G → B → OIII → SII")
        hint.setStyleSheet("color:#aeb6bf;")
        reg_grid.addWidget(hint, 1, 2)

        main.addWidget(reg_box)

        # Outputs
        outputs_box = QGroupBox("3. Outputs")
        outputs_layout = QHBoxLayout(outputs_box)

        col1 = QVBoxLayout()
        self.cb_rgb = QCheckBox("Create RGB")
        self.cb_rgb.setChecked(True)
        self.cb_lrgb = QCheckBox("Create LRGB")
        self.cb_lrgb.setChecked(True)
        self.cb_sho = QCheckBox("Create SHO")
        self.cb_hoo = QCheckBox("Create HOO")
        for w in (self.cb_rgb, self.cb_lrgb, self.cb_sho, self.cb_hoo):
            col1.addWidget(w)

        col2 = QVBoxLayout()
        self.cb_save_l = QCheckBox("Save L separately")
        self.cb_save_l.setChecked(True)
        self.cb_save_registered = QCheckBox("Save all registered channels")
        self.cb_save_registered.setChecked(True)
        col2.addWidget(self.cb_save_l)
        col2.addWidget(self.cb_save_registered)
        col2.addStretch()

        outputs_layout.addLayout(col1)
        outputs_layout.addSpacing(50)
        outputs_layout.addLayout(col2)
        outputs_layout.addStretch()
        main.addWidget(outputs_box)

        # Open in Siril
        open_box = QGroupBox("4. Open in Siril")
        open_layout = QHBoxLayout(open_box)
        self.open_buttons = {}
        for name in ("L", "RGB", "LRGB", "SHO", "HOO"):
            b = QPushButton(f"Open {name}")
            b.setEnabled(False)
            b.clicked.connect(lambda checked=False, n=name: self.open_result(n))
            open_layout.addWidget(b)
            self.open_buttons[name] = b
        main.addWidget(open_box)

        # Process row
        row = QHBoxLayout()
        self.process_btn = QPushButton("PROCESS")
        self.process_btn.setMinimumWidth(150)
        self.process_btn.clicked.connect(self.process)
        row.addWidget(self.process_btn)

        self.status = QLabel("Ready 😎")
        row.addWidget(self.status)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        row.addWidget(self.progress, 1)
        main.addLayout(row)

        # Log
        log_box = QGroupBox("Processing log")
        log_layout = QVBoxLayout(log_box)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(1000)
        self.log.setMinimumHeight(70)
        self.log.setMaximumHeight(110)
        log_layout.addWidget(self.log)
        main.addWidget(log_box, 1)

    def on_file_loaded(self, channel, path):
        self.channel_paths[channel] = Path(path)
        if not self.output_edit.text().strip():
            self.output_edit.setText(str(Path(path).parent / "AG_Channel_Output"))

    def browse_output(self):
        folder = QFileDialog.getExistingDirectory(self, "Select output folder")
        if folder:
            self.output_edit.setText(folder)

    def write_log(self, text):
        self.log.appendPlainText(str(text))
        QApplication.processEvents()
        try:
            self.siril.log(f"[AG Channel Processor] {text}")
        except Exception:
            pass

    def set_status(self, text, value=None):
        self.status.setText(text)
        if value is not None:
            self.progress.setValue(value)
        QApplication.processEvents()

    def cmd(self, *args):
        self.write_log("> " + " ".join(str(a) for a in args))
        self.siril.cmd(*[str(a) for a in args])

    def get_loaded(self):
        loaded = {}
        for ch, path in self.channel_paths.items():
            if path is not None:
                if not path.exists():
                    raise FileNotFoundError(f"{ch}: file not found:\n{path}")
                loaded[ch] = path.resolve()
        return loaded

    def choose_reference(self, loaded):
        requested = self.reference.currentText()
        if requested != "Auto":
            if requested not in loaded:
                raise ValueError(f"Reference '{requested}' is not loaded.")
            return requested
        for ch in REFERENCE_PRIORITY:
            if ch in loaded:
                return ch
        return next(iter(loaded))

    def find_registered(self, folder):
        for pattern in ("reg_regseq_*.fit", "reg_regseq_*.fits", "reg_regseq_*.fts"):
            files = sorted(folder.glob(pattern))
            if files:
                return files
        return []

    def update_open_buttons(self):
        for name, button in self.open_buttons.items():
            p = self.results.get(name)
            button.setEnabled(bool(p and Path(p).exists()))

    def open_result(self, name):
        p = self.results.get(name)
        if not p:
            return

        p = Path(p)
        if not p.exists():
            QMessageBox.critical(self, APP_NAME, f"File not found:\n{p}")
            return

        try:
            # Siril 1.4.x may misparse LOAD paths containing spaces.
            # Copy to a short persistent cache first.
            open_cache = Path(tempfile.gettempdir()) / "AGACP_Open"
            open_cache.mkdir(parents=True, exist_ok=True)

            safe_name = {
                "L": "L.fit",
                "RGB": "RGB.fit",
                "LRGB": "LRGB.fit",
                "SHO": "SHO.fit",
                "HOO": "HOO.fit",
            }.get(name, "result.fit")

            safe_path = open_cache / safe_name
            shutil.copy2(p, safe_path)

            self.write_log(f"Open cache: {safe_path}")
            self.cmd("load", str(safe_path))
            self.set_status(f"Opened {name} in Siril")
            self.write_log(f"✓ Opened in Siril: {p.name}")

            # Keep the processor window alive and bring it back in front
            # after Siril has loaded the selected result.
            self.show()
            self.raise_()
            self.activateWindow()
            QApplication.processEvents()

        except Exception as exc:
            self.write_log(f"ERROR opening {name}: {exc}")
            QMessageBox.critical(
                self,
                APP_NAME,
                f"Could not open {name} in Siril.\n\n{exc}"
            )

    def process(self):
        self.process_btn.setEnabled(False)
        self.results = {}
        self.update_open_buttons()
        self.progress.setValue(0)
        safe_root = None

        try:
            loaded = self.get_loaded()
            if len(loaded) < 2:
                raise ValueError("Load at least two channel stacks.")

            output_text = self.output_edit.text().strip()
            if not output_text:
                raise ValueError("Select an output folder.")

            output = Path(output_text).resolve()
            output.mkdir(parents=True, exist_ok=True)

            reference = self.choose_reference(loaded)
            ordered = [reference] + [ch for ch in CHANNELS if ch in loaded and ch != reference]

            self.write_log("=" * 66)
            self.write_log(f"Reference: {reference}")

            # Use a unique workspace for every run.
            # This avoids WinError 183 if a previous Siril run still has
            # an old temp directory open or if cleanup was interrupted.
            safe_root = Path(tempfile.mkdtemp(prefix="AGACP_Siril_"))

            source = safe_root / "src"
            work = safe_root / "work"
            compose = safe_root / "compose"
            source.mkdir(parents=True, exist_ok=True)
            work.mkdir(parents=True, exist_ok=True)
            compose.mkdir(parents=True, exist_ok=True)

            self.write_log(f"Temp workspace: {safe_root}")

            self.set_status("Preparing channels…", 8)
            for i, ch in enumerate(ordered, 1):
                dst = source / f"{i:02d}_{ch}.fit"
                shutil.copy2(loaded[ch], dst)
                self.write_log(f"✓ {ch} copied")

            self.set_status("Creating sequence…", 18)
            self.cmd("cd", str(source))
            self.cmd("set32bits")
            self.cmd("setext", "fit")
            self.cmd("convert", "regseq", f"-out={work}")

            self.set_status("Registering channels…", 35)
            self.cmd("cd", str(work))
            self.cmd("setref", "regseq", "1")
            self.cmd("register", "regseq", "-transf=homography", "-prefix=reg_")

            registered = self.find_registered(work)
            if len(registered) != len(ordered):
                raise RuntimeError(
                    f"Siril created {len(registered)} registered files, "
                    f"but {len(ordered)} were expected."
                )

            self.set_status("Saving registered channels…", 58)
            registered_out = output / "Registered"
            registered_out.mkdir(parents=True, exist_ok=True)

            reg_out = {}
            for ch, src in zip(ordered, registered):
                shutil.copy2(src, compose / f"{ch}.fit")
                user = registered_out / f"{ch}_registered.fit"
                shutil.copy2(src, user)
                reg_out[ch] = user
                self.write_log(f"✓ {ch} registered")

            if "L" in reg_out:
                if self.cb_save_l.isChecked():
                    lp = output / "L_registered.fit"
                    shutil.copy2(reg_out["L"], lp)
                    self.results["L"] = lp
                else:
                    self.results["L"] = reg_out["L"]

            self.set_status("Creating combinations…", 72)
            self.cmd("cd", str(compose))

            def exists_all(names):
                return all((compose / f"{x}.fit").exists() for x in names)

            if self.cb_rgb.isChecked() and exists_all(("R", "G", "B")):
                self.cmd("rgbcomp", "R.fit", "G.fit", "B.fit", "-out=RGB")
                src = compose / "RGB.fit"
                dst = output / "RGB_by_ag_astrophotography.fit"
                if not src.exists():
                    raise RuntimeError("RGB output was not created by Siril.")
                shutil.copy2(src, dst)
                self.results["RGB"] = dst
                self.write_log("✓ RGB created")

            if self.cb_lrgb.isChecked() and exists_all(("L", "R", "G", "B")):
                self.cmd("rgbcomp", "-lum=L.fit", "R.fit", "G.fit", "B.fit", "-out=LRGB")
                src = compose / "LRGB.fit"
                dst = output / "LRGB_by_ag_astrophotography.fit"
                if not src.exists():
                    raise RuntimeError("LRGB output was not created by Siril.")
                shutil.copy2(src, dst)
                self.results["LRGB"] = dst
                self.write_log("✓ LRGB created")

            if self.cb_sho.isChecked() and exists_all(("SII", "Ha", "OIII")):
                self.cmd("rgbcomp", "SII.fit", "Ha.fit", "OIII.fit", "-out=SHO")
                src = compose / "SHO.fit"
                dst = output / "SHO_by_ag_astrophotography.fit"
                if not src.exists():
                    raise RuntimeError("SHO output was not created by Siril.")
                shutil.copy2(src, dst)
                self.results["SHO"] = dst
                self.write_log("✓ SHO created")

            if self.cb_hoo.isChecked() and exists_all(("Ha", "OIII")):
                self.cmd("rgbcomp", "Ha.fit", "OIII.fit", "OIII.fit", "-out=HOO")
                src = compose / "HOO.fit"
                dst = output / "HOO_by_ag_astrophotography.fit"
                if not src.exists():
                    raise RuntimeError("HOO output was not created by Siril.")
                shutil.copy2(src, dst)
                self.results["HOO"] = dst
                self.write_log("✓ HOO created")

            if not self.cb_save_registered.isChecked():
                # Keep L available if it is the only source for Open L.
                l_tmp = self.results.get("L")
                shutil.rmtree(registered_out, ignore_errors=True)
                if l_tmp and not Path(l_tmp).exists():
                    self.results.pop("L", None)

            self.set_status("DONE 😎", 100)
            self.write_log(f"Output: {output}")
            self.update_open_buttons()

            QMessageBox.information(
                self,
                APP_NAME,
                f"Processing complete 😎\n\nOutput:\n{output}"
            )

        except Exception as exc:
            self.set_status("ERROR", 0)
            self.write_log(f"ERROR: {exc}")
            QMessageBox.critical(self, APP_NAME, str(exc))

        finally:
            if safe_root is not None:
                try:
                    # Move Siril's working directory out of the temporary tree
                    # before Windows cleanup. This reduces locked-folder leftovers.
                    self.siril.cmd("cd", str(Path.home()))
                except Exception:
                    pass

                try:
                    shutil.rmtree(safe_root, ignore_errors=True)
                except Exception:
                    pass

            self.process_btn.setEnabled(True)


def main():
    app = QApplication.instance()
    owns_app = app is None
    if app is None:
        app = QApplication([])

    window = App()
    window.show()

    if owns_app:
        app.exec()


if __name__ == "__main__":
    main()
