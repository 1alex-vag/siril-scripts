Astro Channel Processor by ag_astrophotography
Siril-native v1.5
===============================================

FIX IN v1.5
-----------
Fixes:
[WinError 183] A file cannot be created when it already exists:
...\Temp\AGACP_Siril\compose

Cause:
The older versions reused one fixed temporary directory. If Siril still had
that directory open, or cleanup from a previous run was interrupted, the next
run could collide with it.

v1.5 now:
- creates a UNIQUE temporary workspace for every processing run
- uses tempfile.mkdtemp(prefix="AGACP_Siril_")
- uses exist_ok=True for internal folders
- moves Siril's working directory out of the temp tree before cleanup

Example:
%TEMP%\AGACP_Siril_ab12cd34\

All visual changes and processing features from v1.4 remain unchanged.
