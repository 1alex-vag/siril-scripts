@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "TARGET=C:\Program Files\Siril\scripts"

echo.
echo ========================================================
echo   2x Drizzle OSC scripts by ag_astrophotography
echo   Siril 1.4.x / 1.4.4
echo ========================================================
echo.

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator rights are required.
    echo Relaunching installer as Administrator...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if not exist "%TARGET%" (
    echo ERROR: Siril scripts folder was not found:
    echo %TARGET%
    pause
    exit /b 1
)

copy /Y "2xdrizzle_osc_script_by_ag_astrophotography_Full.ssf" "%TARGET%\" >nul
copy /Y "2xdrizzle_osc_script_by_ag_astrophotography_FromMasters.ssf" "%TARGET%\" >nul

echo.
echo Installed:
echo  - 2xdrizzle_osc_script_by_ag_astrophotography_Full.ssf
echo  - 2xdrizzle_osc_script_by_ag_astrophotography_FromMasters.ssf
echo.
echo Restart Siril to refresh the Scripts menu.
echo.
pause
