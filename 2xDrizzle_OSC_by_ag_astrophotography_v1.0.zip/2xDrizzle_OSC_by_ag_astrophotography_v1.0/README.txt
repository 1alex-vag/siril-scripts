2x Drizzle OSC by ag_astrophotography v1.0
================================================

Target:
Siril 1.4.x / 1.4.4 Stable

FILES
-----
1) 2xdrizzle_osc_script_by_ag_astrophotography_Full.ssf
   Uses:
   biases/
   darks/
   flats/
   lights/

2) 2xdrizzle_osc_script_by_ag_astrophotography_FromMasters.ssf
   Uses:
   masters/master_dark.fit
   masters/master_flat.fit
   lights/

IMPORTANT FOR OSC / CFA
-----------------------
Do NOT debayer the lights before drizzle.

The scripts deliberately calibrate the lights with:
-cfa -equalize_cfa

and do NOT use:
-debayer

The Bayer/CFA pattern is preserved until seqapplyreg performs the
true HST CFA / Bayer drizzle.

SETTINGS
--------
Scale:    2.0x
Pixfrac:  0.7
Kernel:   square
Stack:    MAD clipping 3 / 3
Bitdepth: 32-bit

NOTE
----
2x CFA drizzle is much more demanding on data coverage than 2x mono drizzle.
Good dithering and a healthy number of subframes are strongly recommended.
