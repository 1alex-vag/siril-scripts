2x Drizzle Mono by ag_astrophotography v1.0
================================================

New Siril menu filename:
2xDrizzle_Mono_by_ag_astrophotography.ssf

The installer removes older filenames such as:
- ASI2600MM_Mono_2x_Drizzle_Full_Siril_1.4.ssf
- ASI2600MM_Mono_2x_Drizzle.ssf
- 2xdrizzle_mono_script_by_ag_astrophotography_Full.ssf

Processing behavior is unchanged.
Target: Siril 1.4.x / 1.4.4 Stable.
