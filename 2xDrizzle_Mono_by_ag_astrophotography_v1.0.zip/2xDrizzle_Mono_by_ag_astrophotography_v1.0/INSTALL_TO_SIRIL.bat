@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "TARGET=C:\Program Files\Siril\scripts"
set "SCRIPT=2xDrizzle_Mono_by_ag_astrophotography.ssf"

echo.
echo ========================================================
echo   2x Drizzle Mono by ag_astrophotography
echo ========================================================
echo.

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Administrator rights are required.
    echo Relaunching installer as Administrator...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if not exist "%TARGET%" (
    echo ERROR: Siril scripts folder was not found:
    echo %TARGET%
    pause
    exit /b 1
)

REM Remove older names so the menu stays clean.
del /F /Q "%TARGET%\ASI2600MM_Mono_2x_Drizzle_Full_Siril_1.4.ssf" >nul 2>&1
del /F /Q "%TARGET%\ASI2600MM_Mono_2x_Drizzle.ssf" >nul 2>&1
del /F /Q "%TARGET%\2xdrizzle_mono_script_by_ag_astrophotography_Full.ssf" >nul 2>&1

copy /Y "%SCRIPT%" "%TARGET%\%SCRIPT%" >nul
if errorlevel 1 (
    echo ERROR: Could not copy script.
    pause
    exit /b 1
)

echo.
echo Installed:
echo %TARGET%\%SCRIPT%
echo.
echo Restart Siril to refresh the Scripts menu.
echo.
pause
