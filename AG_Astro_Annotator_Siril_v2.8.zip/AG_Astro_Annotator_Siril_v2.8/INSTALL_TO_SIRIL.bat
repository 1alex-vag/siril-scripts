@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "BASE=C:\Program Files\Siril\scripts"
set "SCRIPT=AG_Astro_Annotator_by_ag_astrophotography.py"

echo.
echo ========================================================
echo  AG Astro Annotator by ag_astrophotography v2.8
echo ========================================================
echo.

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Administrator rights required - relaunching...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

if not exist "%BASE%" (
  echo ERROR: Siril scripts folder not found:
  echo %BASE%
  pause
  exit /b 1
)

if exist "%BASE%\%SCRIPT%" (
  del /F /Q "%BASE%\%SCRIPT%"
)

copy /Y "%SCRIPT%" "%BASE%\%SCRIPT%" >nul
if errorlevel 1 (
  echo ERROR copying script.
  pause
  exit /b 1
)

if not exist "%BASE%\%SCRIPT%" (
  echo ERROR: Script file is missing after copy.
  pause
  exit /b 1
)

if not exist "%BASE%\AG_Astro_Annotator_catalogue" mkdir "%BASE%\AG_Astro_Annotator_catalogue"
xcopy /E /I /Y "AG_Astro_Annotator_catalogue\*" "%BASE%\AG_Astro_Annotator_catalogue\" >nul
if errorlevel 1 (
  echo ERROR copying Siril catalogues.
  pause
  exit /b 1
)

echo Installed successfully: v2.8
echo Bundled Siril 1.4.4 annotation catalogues installed.
echo Restart Siril, then open Scripts - Python Scripts.
echo.
pause
