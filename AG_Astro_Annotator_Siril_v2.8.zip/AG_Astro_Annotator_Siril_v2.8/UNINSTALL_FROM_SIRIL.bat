@echo off
setlocal EnableExtensions
set "FILE=C:\Program Files\Siril\scripts\AG_Astro_Annotator_by_ag_astrophotography.py"
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
if exist "%FILE%" del /F /Q "%FILE%"
if exist "C:\Program Files\Siril\scripts\AG_Astro_Annotator_catalogue" rmdir /S /Q "C:\Program Files\Siril\scripts\AG_Astro_Annotator_catalogue"
echo Removed AG Astro Annotator.
pause
