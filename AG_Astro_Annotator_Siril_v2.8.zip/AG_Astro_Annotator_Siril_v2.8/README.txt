AG Astro Annotator by ag_astrophotography v2.0
=================================================

Target
------
Siril 1.4.x / Siril 1.4.4 Stable on Windows.

v2.0 changes
-------------
- Slider controls for grid width, opacity, font size, marker size and preview stretch.
- Font size increased to 300 px.
- Zoom preview with mouse wheel.
- Pan preview by dragging.
- Fit to Scale button.
- Simple non-destructive preview stretch with reset.
- Plate Solve (Siril) button using Siril's scriptable platesolve command.
- Label color is independent from grid color unless "Use grid color for labels" is enabled.
- Label position: Right, Left, Center, Custom X/Y offsets.
- Larger window and scrollable settings area.
- RGB FITS with NAXIS=3 + 2-D SIP/WCS remains supported.

Plate Solve
-----------
The button loads a temporary copy into Siril, runs Siril's platesolve command,
saves the solved copy, then reloads its WCS into the Annotator.

Siril's solver may require usable metadata such as approximate center,
focal length and/or pixel size. If the automatic command cannot solve the image,
use Siril's normal Image Plate Solver dialog to provide the missing data.

Preview
-------
Mouse wheel: zoom in/out
Drag: pan
Fit to Scale: fit whole frame
Click: fill custom X/Y (and RA/Dec if WCS is present)
Stretch: preview/output presentation stretch only; original FITS is unchanged

Save
----
Overlay PNG: transparent grid/labels/markers only
Complete PNG/TIFF: presentation image + overlay
Presentation FITS: rendered presentation result with overlay burned in
Original scientific FITS is never overwritten.

CSV
---
Name,RA,Dec
M31,00:42:44.3,+41:16:09
NGC7000,20:58:54,+44:19:00


v2.0 changes
-------------
- Preview stretch slider replaced by AutoStretch (Siril) ON/OFF.
- AutoStretch preview is requested from Siril itself.
- Sections 1-5 are collapsible; only Input is open at startup.
- Preview enlarged; Annotations table reduced in height.
- RA/Dec grid labels now use the selected Label color.
- RA/Dec grid labels now obey Right / Left / Center / Custom positioning.
- Presentation FITS vertical orientation corrected for Siril display.
- Added Save overlay TIFF (RGBA / transparency).


v2.0 changes
-------------
- Preview section removed; AutoStretch checkbox moved into Input.
- Fit to Scale moved above preview; double-click preview resets fit.
- Separate horizontal and vertical grid colors.
- Optional WCS compass with corner position.
- Label font size up to 500 px with manual numeric entry.
- Line width up to 30 px with manual numeric entry.
- New Catalog section: CSV import or SIMBAD query (internet required).
- Custom text size added; marker size up to 1500 px.
- Add X/Y and Add RA/Dec merged into single Add button.


v2.0 fixes
----------
- RA/Dec labels are anchored to their own WCS grid line.
- Left / Center / Right chooses a position along each individual line.
- Horizontal/Vertical grid color buttons use equal widths.
- Fixed SIMBAD catalog loading for TAP-era lowercase columns
  (main_id / ra / dec), while retaining compatibility with older uppercase names.
- Catalog coordinates accept both decimal-degree and sexagesimal responses.


v2.0 catalog rewrite
--------------------
- Replaced SIMBAD-based Messier/NGC/IC/Sh2 lookup with Siril's own offline
  annotation catalogues from %LOCALAPPDATA%\siril\catalogue.
- No arbitrary Max Objects limit.
- Selected catalogs can auto-load as soon as a WCS solution is available.
- Objects are filtered directly by the image WCS / field of view.
- When a catalogue entry provides diameter (arcmin), its angular size is
  converted to image pixels and displayed as a circle.
- Catalog choices: Messier, NGC, IC, Sharpless/Sh2, Lynds Dark Nebulae.
- Custom CSV import remains available.


v2.0 fixes
----------
- Bundles the official Siril 1.4.4 annotation CSV catalogues directly:
  messier.csv, ngc.csv, ic.csv, sh2.csv, ldn.csv.
- Catalog lookup no longer depends on %LOCALAPPDATA% or Siril's install layout.
- Installer copies the catalogue folder next to the Python script.
- Compass is enabled by default (still switchable off and position-selectable).


v2.0 final polish
-----------------
- Catalog labels have their own 8-500 px font-size control.
- Catalog marker style: Auto (object size), Circle, Box, Crosshair, Text only.
- Catalog fallback marker size up to 1500 px.
- Compass enlarged and rendered on a translucent badge for guaranteed visibility.
- Preview/PNG/TIFF/overlay orientation vertically aligned with Siril display.
- Preview clicks are transformed back to original FITS/WCS coordinates.


v2.0 fixes
----------
- Fixed mirrored/upside-down overlay text in Siril-oriented preview.
- WCS lines/markers are transformed into Siril display coordinates first;
  text is rendered afterwards and remains readable.
- Compass size is adjustable from 100 to 700 px.
- Separate Compass opacity and Background opacity controls.
- Compass N/E orientation is calculated from the WCS at image center and
  converted into Siril's visual orientation.
- Compass renders last, so it stays visible above grid/catalog overlays.


v2.0
----------
- Corrected internal version string that incorrectly still displayed v1.8.
- Window title now shows [1.9-fixed] so installation can be verified instantly.
- Installer explicitly deletes the previous Python script before copying the new one.


v2.0
----
- Active preview/save renderer no longer flips a finished text bitmap.
- Grid/object coordinates are transformed first; text remains readable.
- Compass controls: size 100-800 px, compass opacity, background opacity.
- Window build marker: [2.0-release-candidate].


v2.1 changes
-------------
- Grid coordinate labels now follow a cleaner Siril-like border placement.
- RA labels use HHhMMm formatting on the bottom edge.
- Dec labels use ±DD°MM' formatting on the right edge.
- Compass frame/badge removed; only simple N/E arrows remain.
- N arrow is red, E arrow is white, with adjustable opacity/shadow.


v2.2 changes
-------------
- Added selectable Grid aspect: 1×1 (Siril-like), 2×1, 1×2, Legacy.
- 1×1 corrects RA spacing by cos(Dec) for approximately square sky cells.
- RA labels now rotate 90 degrees at the bottom edge, like Siril.
- Dec labels remain horizontal at the right edge.
- RA/Dec formatting refined to 21h15m and +68°30'.
- Compass N/E letters moved below the arrow tips.


v2.8 changes
-------------
- RA coordinate labels follow the local tangent of each RA grid line.
- Rotated RA text is clamped fully inside the image so it is never cut off.
- Compass is now a real annotation with X/Y and RA/Dec position editing.
- New 6. Annotations section on the left with a multi-row table and Apply Position.
- Save moved to 7. Save.
- Right side is dedicated mainly to the larger Preview.


v2.8 RA text fix
----------------
- No functional/UI changes besides RA coordinate text rendering.
- Correctly compensates Pillow/TrueType negative glyph bearings.
- Adds generous glyph padding before rotation.
- Uses the final rotated bounding box to keep the complete RA label on-image.


v2.8 final fixes
-----------------
- Removed grid label position selector: coordinate positions are fixed Siril-style.
- Grid lines are erased underneath RA/Dec coordinate text, matching Siril's clean label gaps.
- Compass Apply Position now detects whether X/Y or RA/Dec was actually edited.
- Suppressed harmless Astropy SIP inverse-convergence warnings from grid trial points.
- Reduced grid trial points outside image bounds to avoid unnecessary WCS inversion warnings.


v2.8 changes
-------------
- Added "Siril Auto" grid spacing mode.
- Automatic grid now chooses independent RA and Dec intervals from common astronomical steps.
- This makes dense fields at high declination much closer to Siril's own automatic grid density.
- Manual spacing modes and Grid aspect options remain available for custom control.


v2.8 adaptive Siril grid
-------------------------
- Fixed Siril Auto RA step calculation (RA minutes of time, not sky arcminutes).
- Grid labels now choose bottom OR right border dynamically from the actual WCS line geometry.
- Labels rotate parallel to the local grid-line tangent.
- Bottom labels sit beside the line; right-border labels sit above the line, matching Siril's presentation.
- This prevents landscape/rotated frames from forcing RA labels onto the wrong edge.
