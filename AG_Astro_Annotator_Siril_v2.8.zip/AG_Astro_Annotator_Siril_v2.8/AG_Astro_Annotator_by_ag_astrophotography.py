"""
AG Astro Annotator by ag_astrophotography v1.9
Target: Siril 1.4.x / 1.4.4 Stable (Windows)

v1.9:
- slider-based controls
- zoomable/pannable preview (mouse wheel)
- preview stretch slider + reset
- Fit to Scale
- Siril plate-solve button
- label color logic clarified/fixed
- font size up to 300 px
- label position: Left / Right / Center / Custom
- larger default window / improved layout
- v1.1 3-channel RGB FITS + 2-D SIP/WCS fix retained
"""

import csv
import math
import warnings
import os
import re
import shutil
import tempfile
from pathlib import Path

import sirilpy as s
for pkg in ("PyQt6", "astropy", "numpy", "Pillow"):
    s.ensure_installed(pkg)

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from astropy.io import fits
from astropy.wcs import WCS
from astropy.coordinates import SkyCoord
import astropy.units as u

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPixmap, QImage, QFont, QPainter
from PyQt6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QPushButton, QFileDialog,
    QVBoxLayout, QHBoxLayout, QGridLayout, QGroupBox, QLineEdit,
    QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox, QColorDialog,
    QProgressBar, QPlainTextEdit, QMessageBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QSplitter, QAbstractSpinBox,
    QSlider, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem,
    QScrollArea, QToolButton
)

APP = "AG Astro Annotator by ag_astrophotography"
VER = "2.8"
BUILD = "2.8-adaptive-siril-labels"
GRID_DEFAULT = "#68d7ff"
LABEL_DEFAULT = "#ffffff"
CUSTOM_DEFAULT = "#ffcc66"

# Astropy SIP inverse warnings can occur for trial grid points near/outside
# distorted image edges. They do not invalidate the solved WCS and would
# otherwise flood Siril's console in red.
warnings.filterwarnings(
    "ignore",
    message=r".*WCS\.all_world2pix.*failed to converge.*",
    category=UserWarning,
    module=r"astropy\.wcs.*"
)
warnings.filterwarnings(
    "ignore",
    message=r".*solution is diverging.*",
    category=UserWarning,
    module=r"astropy\.wcs.*"
)
warnings.filterwarnings(
    "ignore",
    message=r"All-NaN slice encountered",
    category=RuntimeWarning
)


def rgba(hexv, a=255):
    c = QColor(hexv)
    return (c.red(), c.green(), c.blue(), a)


def pil_font(size):
    size = max(8, int(size))
    for p in (
        r"C:\Windows\Fonts\segoeui.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
    ):
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size=size)
            except Exception:
                pass
    return ImageFont.load_default()


class SliderRow(QWidget):
    valueChanged = pyqtSignal(int)

    def __init__(self, minimum, maximum, value, suffix="", scale=1.0, decimals=0):
        super().__init__()
        self.scale = float(scale)
        self.suffix = suffix
        self.decimals = decimals
        self._updating = False

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(7)

        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(int(minimum), int(maximum))
        self.slider.setValue(int(value))

        self.spin = QDoubleSpinBox()
        self.spin.setDecimals(decimals)
        self.spin.setRange(minimum * self.scale, maximum * self.scale)
        self.spin.setSingleStep(max(0.1 if decimals else 1.0, self.scale))
        self.spin.setSuffix(suffix)
        self.spin.setMinimumWidth(92)

        lay.addWidget(self.slider, 1)
        lay.addWidget(self.spin)

        self.slider.valueChanged.connect(self._slider_changed)
        self.spin.valueChanged.connect(self._spin_changed)
        self._slider_changed(int(value))

    def _slider_changed(self, v):
        if self._updating:
            return
        self._updating = True
        self.spin.setValue(v * self.scale)
        self._updating = False
        self.valueChanged.emit(v)

    def _spin_changed(self, val):
        if self._updating:
            return
        self._updating = True
        self.slider.setValue(int(round(float(val) / self.scale)))
        self._updating = False
        self.valueChanged.emit(self.slider.value())

    def get(self):
        return float(self.spin.value())

    def set(self, value):
        self.spin.setValue(float(value))


class DropBox(QFrame):
    dropped = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("drop")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setMinimumHeight(100)
        self.setStyleSheet("""
            QFrame#drop {
                background:#2c3136;
                border:2px dashed #59636c;
                border-radius:10px;
            }
            QFrame#drop:hover { border-color:#68d7ff; }
            QLabel { background:transparent; border:none; }
        """)
        lay = QVBoxLayout(self)
        self.title = QLabel("DROP FITS HERE")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        lay.addWidget(self.title)

        self.path_label = QLabel("plate-solved or unsolved • or click Browse")
        self.path_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.path_label.setStyleSheet("color:#aeb6bf")
        lay.addWidget(self.path_label)

        row = QHBoxLayout()
        self.browse = QPushButton("Browse…")
        self.clear = QPushButton("Clear")
        row.addStretch()
        row.addWidget(self.browse)
        row.addWidget(self.clear)
        row.addStretch()
        lay.addLayout(row)

    def set_file(self, p):
        p = Path(p)
        self.title.setText("✓ " + p.name)
        self.path_label.setText(str(p.parent))
        self.dropped.emit(str(p))

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            p = Path(e.mimeData().urls()[0].toLocalFile())
            if p.suffix.lower() in (".fit", ".fits", ".fts"):
                e.acceptProposedAction()
                return
        e.ignore()

    def dropEvent(self, e):
        p = e.mimeData().urls()[0].toLocalFile()
        self.set_file(p)
        e.acceptProposedAction()


class ZoomPreview(QGraphicsView):
    imageClicked = pyqtSignal(float, float)

    def __init__(self):
        super().__init__()
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        self.pix_item = QGraphicsPixmapItem()
        self.scene_obj.addItem(self.pix_item)
        self.setBackgroundBrush(QColor("#111417"))
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setRenderHints(QPainter.RenderHint.SmoothPixmapTransform)
        self.setMinimumSize(760, 520)
        self._w = 0
        self._h = 0
        self._has_image = False

    def set_image(self, pixmap, w, h, fit=False):
        self._w, self._h = w, h
        self.pix_item.setPixmap(pixmap)
        self.scene_obj.setSceneRect(self.pix_item.boundingRect())
        self._has_image = True
        if fit:
            self.fit_to_scale()

    def fit_to_scale(self):
        if self._has_image:
            self.resetTransform()
            self.fitInView(self.pix_item, Qt.AspectRatioMode.KeepAspectRatio)

    def wheelEvent(self, e):
        if not self._has_image:
            return super().wheelEvent(e)
        factor = 1.22 if e.angleDelta().y() > 0 else 1 / 1.22
        current = self.transform().m11()
        target = current * factor
        if 0.03 <= target <= 30:
            self.scale(factor, factor)

    def mousePressEvent(self, e):
        if self._has_image and e.button() == Qt.MouseButton.LeftButton:
            pt = self.mapToScene(e.position().toPoint())
            if self.pix_item.contains(pt):
                self.imageClicked.emit(float(pt.x()), float(pt.y()))
        super().mousePressEvent(e)

    def mouseDoubleClickEvent(self, e):
        if self._has_image and e.button() == Qt.MouseButton.LeftButton:
            self.fit_to_scale()
            e.accept()
            return
        super().mouseDoubleClickEvent(e)


class CollapsibleSection(QFrame):
    """Compact collapsible section used for settings panels."""
    def __init__(self, title, expanded=False):
        super().__init__()
        self.setObjectName("collapsible")
        self.setStyleSheet("""
            QFrame#collapsible {
                border:1px solid #454d55;
                border-radius:7px;
                background:#25292d;
            }
            QToolButton {
                text-align:left;
                font-weight:600;
                padding:7px 9px;
                background:#30363c;
                border:none;
                border-radius:6px;
            }
            QToolButton:hover { background:#394149; }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.header = QToolButton()
        self.header.setText(title)
        self.header.setCheckable(True)
        self.header.setChecked(expanded)
        self.header.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        root.addWidget(self.header)

        self.body = QWidget()
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(9, 8, 9, 9)
        self.body_layout.setSpacing(6)
        root.addWidget(self.body)

        self.header.toggled.connect(self.set_expanded)
        self.set_expanded(expanded)

    def set_expanded(self, expanded):
        self.body.setVisible(expanded)
        self.header.setArrowType(
            Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow
        )



class App(QWidget):
    def __init__(self):
        super().__init__()
        self.si = s.SirilInterface()
        self.si.connect()
        self.si.cmd("requires", "1.4.0")

        self.path = None
        self.original_path = None
        self.hdr = None
        self.wcs = None
        self.raw_rgb = None
        self.rgb = None
        self.objects = []
        self.results = {}

        self.hgrid_color = "#ff5f5f"
        self.vgrid_color = "#4fa8ff"
        self.label_color = LABEL_DEFAULT
        self.custom_color = CUSTOM_DEFAULT
        self.catalog_objects = []
        script_dir = Path(__file__).resolve().parent
        self.catalog_dirs = [
            script_dir / "AG_Astro_Annotator_catalogue",
            Path(os.environ.get("LOCALAPPDATA", "")) / "siril" / "catalogue",
            script_dir.parent / "data",
            script_dir.parent / "share" / "siril" / "data",
        ]

        self.setWindowTitle(f"{APP} v{VER}  [{BUILD}]")
        self.resize(1500, 940)
        self.setMinimumSize(1220, 760)

        self.setStyleSheet("""
            QWidget {
                background:#232629;
                color:#eeeeee;
                font-family:'Segoe UI';
                font-size:9pt;
            }
            QGroupBox {
                border:1px solid #454d55;
                border-radius:7px;
                margin-top:9px;
                padding-top:9px;
                font-weight:600;
            }
            QGroupBox::title {
                subcontrol-origin:margin;
                left:10px;
                padding:0 5px;
            }
            QLineEdit,QComboBox,QPlainTextEdit,QTableWidget {
                background:#2b2f33;
                border:1px solid #454d55;
                border-radius:4px;
                padding:4px;
                color:#eee;
            }
            QSpinBox,QDoubleSpinBox {
                background:#2b2f33;
                border:1px solid #454d55;
                border-radius:4px;
                padding:4px;
                padding-right:22px;
                color:#eee;
            }
            QSpinBox::up-button, QDoubleSpinBox::up-button,
            QSpinBox::down-button, QDoubleSpinBox::down-button {
                subcontrol-origin:border;
                width:18px;
                background:#343a40;
                border-left:1px solid #454d55;
            }
            QSpinBox::up-button, QDoubleSpinBox::up-button {
                subcontrol-position:top right;
                border-top-right-radius:4px;
            }
            QSpinBox::down-button, QDoubleSpinBox::down-button {
                subcontrol-position:bottom right;
                border-bottom-right-radius:4px;
                border-top:1px solid #454d55;
            }
            QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover,
            QSpinBox::down-button:hover, QDoubleSpinBox::down-button:hover {
                background:#46505a;
            }
            QPushButton {
                background:#3a4148;
                color:#eee;
                border:none;
                border-radius:5px;
                padding:6px 10px;
            }
            QPushButton:hover { background:#4a90e2; }
            QPushButton:disabled { background:#2b2f33; color:#70777e; }
            QHeaderView::section {
                background:#343a40;
                color:#eee;
                border:1px solid #454d55;
                padding:4px;
            }
            QProgressBar {
                border:1px solid #454d55;
                border-radius:4px;
                background:#2b2f33;
                text-align:center;
            }
            QProgressBar::chunk { background:#4a90e2; }
            QSlider::groove:horizontal {
                height:6px;
                background:#454d55;
                border-radius:3px;
            }
            QSlider::handle:horizontal {
                background:#d8dde2;
                width:16px;
                margin:-5px 0;
                border-radius:8px;
            }
        """)
        self.build_ui()

    def build_ui(self):
        main = QVBoxLayout(self)
        main.setContentsMargins(12, 9, 12, 9)
        main.setSpacing(6)

        title = QLabel(APP)
        title.setFont(QFont("Segoe UI", 19, QFont.Weight.Bold))
        main.addWidget(title)

        subtitle = QLabel("WCS grid • dual-color grid • catalog labels • Siril plate solve • custom comet markers • transparent overlay")
        subtitle.setStyleSheet("color:#aeb6bf")
        main.addWidget(subtitle)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        main.addWidget(splitter, 1)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setMinimumWidth(520)

        left = QWidget()
        left_scroll.setWidget(left)
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 6, 0)
        ll.setSpacing(6)

        # 1 Input
        sec1 = CollapsibleSection("1. Input", expanded=True)
        self.drop = DropBox()
        sec1.body_layout.addWidget(self.drop)
        row = QHBoxLayout()
        self.platesolve_btn = QPushButton("Plate Solve (Siril)")
        self.autostretch = QCheckBox("AutoStretch (Siril)")
        self.autostretch.setChecked(True)
        row.addWidget(self.platesolve_btn)
        row.addWidget(self.autostretch)
        sec1.body_layout.addLayout(row)
        self.wcs_state = QLabel("WCS: no image")
        self.wcs_state.setStyleSheet("color:#aeb6bf")
        sec1.body_layout.addWidget(self.wcs_state)
        self.drop.dropped.connect(self.load_fits)
        self.drop.browse.clicked.connect(self.browse)
        self.drop.clear.clicked.connect(self.clear_input)
        self.platesolve_btn.clicked.connect(self.plate_solve)
        self.autostretch.toggled.connect(self.rebuild_display)
        ll.addWidget(sec1)

        # 2 Grid
        sec2 = CollapsibleSection("2. Grid", expanded=False)
        gw = QWidget()
        gg = QGridLayout(gw)
        gg.setContentsMargins(0,0,0,0)
        self.grid = QCheckBox("Show RA / Dec grid")
        self.grid.setChecked(True)
        self.grid.toggled.connect(self.refresh)
        gg.addWidget(self.grid, 0, 0, 1, 2)

        gg.addWidget(QLabel("Spacing"), 1, 0)
        self.spacing = QComboBox()
        self.spacing.addItems(["Siril Auto", "0.1°", "0.25°", "0.5°", "1°", "2°", "5°", "10°"])
        self.spacing.setCurrentText("0.5°")
        self.spacing.currentTextChanged.connect(self.refresh)
        gg.addWidget(self.spacing, 1, 1)

        gg.addWidget(QLabel("Grid aspect"), 2, 0)
        self.grid_aspect = QComboBox()
        self.grid_aspect.addItems(["1×1 (Siril-like)", "2×1", "1×2", "Legacy"])
        self.grid_aspect.setCurrentText("1×1 (Siril-like)")
        self.grid_aspect.currentTextChanged.connect(self.refresh)
        gg.addWidget(self.grid_aspect, 2, 1)

        gg.addWidget(QLabel("Line width"), 3, 0)
        self.grid_width = SliderRow(1, 300, 15, " px", scale=0.1, decimals=1)
        self.grid_width.valueChanged.connect(lambda _: self.refresh())
        gg.addWidget(self.grid_width, 3, 1)

        gg.addWidget(QLabel("Opacity"), 4, 0)
        self.grid_opacity = SliderRow(0, 100, 65, " %")
        self.grid_opacity.valueChanged.connect(lambda _: self.refresh())
        gg.addWidget(self.grid_opacity, 4, 1)

        self.hgrid_color_btn = QPushButton("Horizontal color")
        self.hgrid_color_btn.setMinimumWidth(180)
        self.hgrid_color_btn.clicked.connect(lambda: self.pick_color("hgrid"))
        gg.addWidget(self.hgrid_color_btn, 5, 0)
        self.vgrid_color_btn = QPushButton("Vertical color")
        self.vgrid_color_btn.setMinimumWidth(180)
        self.vgrid_color_btn.clicked.connect(lambda: self.pick_color("vgrid"))
        gg.addWidget(self.vgrid_color_btn, 5, 1)
        gg.setColumnStretch(0, 1)
        gg.setColumnStretch(1, 1)

        sec2.body_layout.addWidget(gw)
        ll.addWidget(sec2)

        # 3 Labels
        sec3 = CollapsibleSection("3. Labels", expanded=False)
        lw = QWidget()
        lg = QGridLayout(lw)
        lg.setContentsMargins(0,0,0,0)
        self.labels = QCheckBox("Show labels")
        self.labels.setChecked(True)
        self.labels.toggled.connect(self.refresh)
        lg.addWidget(self.labels, 0, 0, 1, 2)

        self.same_color = QCheckBox("Use grid color for coordinate labels")
        self.same_color.setChecked(False)
        self.same_color.toggled.connect(self.same_color_changed)
        lg.addWidget(self.same_color, 1, 0, 1, 2)

        lg.addWidget(QLabel("Font size"), 2, 0)
        self.font_size = SliderRow(8, 500, 18, " px")
        self.font_size.valueChanged.connect(lambda _: self.refresh())
        lg.addWidget(self.font_size, 2, 1)

        fixed_hint = QLabel("Coordinate label placement: Siril-style (fixed)")
        fixed_hint.setStyleSheet("color:#aeb6bf")
        lg.addWidget(fixed_hint, 3, 0, 1, 2)

        self.label_color_btn = QPushButton("Label color")
        self.label_color_btn.clicked.connect(lambda: self.pick_color("label"))
        lg.addWidget(self.label_color_btn, 4, 0, 1, 2)
        sec3.body_layout.addWidget(lw)
        ll.addWidget(sec3)

        # 4 Catalog
        sec4 = CollapsibleSection("4. Catalog", expanded=False)
        cw = QWidget()
        cg = QGridLayout(cw)
        cg.setContentsMargins(0,0,0,0)

        self.cat_messier = QCheckBox("Messier (M)")
        self.cat_messier.setChecked(True)
        self.cat_ngc = QCheckBox("NGC")
        self.cat_ngc.setChecked(True)
        self.cat_ic = QCheckBox("IC")
        self.cat_ic.setChecked(True)
        self.cat_sh2 = QCheckBox("Sharpless (Sh2)")
        self.cat_sh2.setChecked(True)
        self.cat_ldn = QCheckBox("Lynds Dark Nebulae (LdN)")
        self.cat_ldn.setChecked(False)

        cg.addWidget(self.cat_messier, 0, 0)
        cg.addWidget(self.cat_ngc, 0, 1)
        cg.addWidget(self.cat_ic, 1, 0)
        cg.addWidget(self.cat_sh2, 1, 1)
        cg.addWidget(self.cat_ldn, 2, 0, 1, 2)

        self.catalog_auto = QCheckBox("Auto-load selected catalogs after WCS/plate solve")
        self.catalog_auto.setChecked(True)
        cg.addWidget(self.catalog_auto, 3, 0, 1, 2)

        cg.addWidget(QLabel("Catalog font size"), 4, 0)
        self.catalog_font_size = SliderRow(8, 500, 24, " px")
        self.catalog_font_size.valueChanged.connect(lambda _: self.refresh())
        cg.addWidget(self.catalog_font_size, 4, 1)

        cg.addWidget(QLabel("Catalog marker"), 5, 0)
        self.catalog_marker_style = QComboBox()
        self.catalog_marker_style.addItems(["Auto (object size)", "Circle", "Box", "Crosshair", "Text only"])
        self.catalog_marker_style.currentTextChanged.connect(self.refresh)
        cg.addWidget(self.catalog_marker_style, 5, 1)

        cg.addWidget(QLabel("Fallback marker size"), 6, 0)
        self.catalog_marker_size = SliderRow(10, 1500, 80, " px")
        self.catalog_marker_size.valueChanged.connect(lambda _: self.refresh())
        cg.addWidget(self.catalog_marker_size, 6, 1)

        self.catalog_btn = QPushButton("Load Siril catalogs")
        self.catalog_btn.clicked.connect(self.load_catalog)
        cg.addWidget(self.catalog_btn, 7, 0)

        self.csv_btn = QPushButton("Import custom CSV…")
        self.csv_btn.clicked.connect(self.import_csv)
        cg.addWidget(self.csv_btn, 7, 1)

        self.clear_catalog_btn = QPushButton("Clear catalog labels")
        self.clear_catalog_btn.clicked.connect(self.clear_catalog)
        cg.addWidget(self.clear_catalog_btn, 8, 0, 1, 2)

        self.catalog_status = QLabel("Uses bundled official Siril 1.4.4 annotation catalogues")
        self.catalog_status.setWordWrap(True)
        self.catalog_status.setStyleSheet("color:#aeb6bf")
        cg.addWidget(self.catalog_status, 9, 0, 1, 2)

        sec4.body_layout.addWidget(cw)
        ll.addWidget(sec4)

        # 5 Custom
        sec5 = CollapsibleSection("5. Custom object / comet", expanded=False)
        xw = QWidget()
        xg = QGridLayout(xw)
        xg.setContentsMargins(0,0,0,0)
        xg.addWidget(QLabel("Text"), 0, 0)
        self.custom_text = QLineEdit("Comet")
        xg.addWidget(self.custom_text, 0, 1, 1, 3)
        xg.addWidget(QLabel("Text size"), 1, 0)
        self.custom_text_size = SliderRow(8, 500, 22, " px")
        self.custom_text_size.valueChanged.connect(lambda _: self.refresh())
        xg.addWidget(self.custom_text_size, 1, 1, 1, 3)
        xg.addWidget(QLabel("Shape"), 2, 0)
        self.shape = QComboBox()
        self.shape.addItems(["Box", "Circle", "Crosshair", "Text only"])
        xg.addWidget(self.shape, 2, 1)
        xg.addWidget(QLabel("Marker size"), 2, 2)
        self.marker_size = SliderRow(10, 1500, 50, " px")
        xg.addWidget(self.marker_size, 2, 3)
        xg.addWidget(QLabel("X"), 3, 0)
        self.cx = QDoubleSpinBox(); self.cx.setRange(0, 100000); self.cx.setDecimals(2)
        xg.addWidget(self.cx, 3, 1)
        xg.addWidget(QLabel("Y"), 3, 2)
        self.cy = QDoubleSpinBox(); self.cy.setRange(0, 100000); self.cy.setDecimals(2)
        xg.addWidget(self.cy, 3, 3)
        xg.addWidget(QLabel("RA"), 4, 0)
        self.ra = QLineEdit(); self.ra.setPlaceholderText("hh:mm:ss or deg")
        xg.addWidget(self.ra, 4, 1)
        xg.addWidget(QLabel("Dec"), 4, 2)
        self.dec = QLineEdit(); self.dec.setPlaceholderText("+dd:mm:ss or deg")
        xg.addWidget(self.dec, 4, 3)
        self.custom_color_btn = QPushButton("Custom color")
        self.custom_color_btn.clicked.connect(lambda: self.pick_color("custom"))
        xg.addWidget(self.custom_color_btn, 5, 0, 1, 2)
        self.add_btn = QPushButton("Add")
        self.add_btn.clicked.connect(self.add_custom)
        xg.addWidget(self.add_btn, 5, 2, 1, 2)
        tip = QLabel("Tip: click in preview to fill X / Y. If RA / Dec is filled, Add uses celestial coordinates.")
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#aeb6bf")
        xg.addWidget(tip, 6, 0, 1, 4)
        sec5.body_layout.addWidget(xw)
        ll.addWidget(sec5)

        # 6 Annotations
        sec6 = CollapsibleSection("6. Annotations", expanded=False)
        aw = QWidget()
        ag = QVBoxLayout(aw)
        ag.setContentsMargins(0,0,0,0)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Name", "X", "Y", "RA", "Dec", "Type"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setMinimumHeight(210)
        self.table.setMaximumHeight(320)
        self.table.itemSelectionChanged.connect(self.annotation_selection_changed)
        ag.addWidget(self.table)

        edit = QGridLayout()
        edit.addWidget(QLabel("Selected X"), 0, 0)
        self.ann_x = QDoubleSpinBox(); self.ann_x.setRange(-100000, 100000); self.ann_x.setDecimals(2); self.ann_x.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
        edit.addWidget(self.ann_x, 0, 1)
        edit.addWidget(QLabel("Y"), 0, 2)
        self.ann_y = QDoubleSpinBox(); self.ann_y.setRange(-100000, 100000); self.ann_y.setDecimals(2); self.ann_y.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
        edit.addWidget(self.ann_y, 0, 3)
        edit.addWidget(QLabel("RA"), 1, 0)
        self.ann_ra = QLineEdit(); self.ann_ra.setPlaceholderText("hh:mm:ss or deg")
        edit.addWidget(self.ann_ra, 1, 1)
        edit.addWidget(QLabel("Dec"), 1, 2)
        self.ann_dec = QLineEdit(); self.ann_dec.setPlaceholderText("+dd:mm:ss or deg")
        edit.addWidget(self.ann_dec, 1, 3)
        ag.addLayout(edit)

        ann_buttons = QHBoxLayout()
        apply_ann = QPushButton("Apply Position")
        apply_ann.clicked.connect(self.apply_annotation_position)
        remove = QPushButton("Remove selected")
        remove.clicked.connect(self.remove_selected)
        clear = QPushButton("Clear annotations")
        clear.clicked.connect(self.clear_annotations)
        ann_buttons.addWidget(apply_ann)
        ann_buttons.addWidget(remove)
        ann_buttons.addWidget(clear)
        ag.addLayout(ann_buttons)

        compass_group = QGroupBox("Compass annotation")
        cgg = QGridLayout(compass_group)
        self.show_compass = QCheckBox("Show compass")
        self.show_compass.setChecked(True)
        self.show_compass.toggled.connect(self.compass_visibility_changed)
        cgg.addWidget(self.show_compass, 0, 0)
        self.compass_pos = QComboBox()
        self.compass_pos.addItems(["Top Left", "Top Right", "Bottom Left", "Bottom Right"])
        self.compass_pos.currentTextChanged.connect(self.compass_preset_changed)
        cgg.addWidget(self.compass_pos, 0, 1)
        cgg.addWidget(QLabel("Size"), 1, 0)
        self.compass_size = SliderRow(100, 800, 320, " px")
        self.compass_size.valueChanged.connect(lambda _: self.refresh())
        cgg.addWidget(self.compass_size, 1, 1)
        cgg.addWidget(QLabel("Compass opacity"), 2, 0)
        self.compass_opacity = SliderRow(0, 100, 100, " %")
        self.compass_opacity.valueChanged.connect(lambda _: self.refresh())
        cgg.addWidget(self.compass_opacity, 2, 1)
        cgg.addWidget(QLabel("Shadow opacity"), 3, 0)
        self.compass_bg_opacity = SliderRow(0, 100, 35, " %")
        self.compass_bg_opacity.valueChanged.connect(lambda _: self.refresh())
        cgg.addWidget(self.compass_bg_opacity, 3, 1)
        ag.addWidget(compass_group)

        sec6.body_layout.addWidget(aw)
        ll.addWidget(sec6)

        # 7 Save
        savebox = QGroupBox("7. Save")
        sg = QGridLayout(savebox)
        sg.addWidget(QLabel("Output"), 0, 0)
        self.out = QLineEdit()
        sg.addWidget(self.out, 0, 1, 1, 2)
        outbrowse = QPushButton("Browse…")
        outbrowse.clicked.connect(self.browse_out)
        sg.addWidget(outbrowse, 0, 3)
        b = QPushButton("Save overlay PNG"); b.clicked.connect(self.save_overlay); sg.addWidget(b, 1, 0, 1, 2)
        b = QPushButton("Save complete PNG"); b.clicked.connect(lambda: self.save_complete("png")); sg.addWidget(b, 1, 2, 1, 2)
        b = QPushButton("Save overlay TIFF"); b.clicked.connect(self.save_overlay_tiff); sg.addWidget(b, 2, 0, 1, 2)
        b = QPushButton("Save complete TIFF"); b.clicked.connect(lambda: self.save_complete("tif")); sg.addWidget(b, 2, 2, 1, 2)
        b = QPushButton("Save presentation FITS"); b.clicked.connect(self.save_fits); sg.addWidget(b, 3, 0, 1, 4)
        ll.addWidget(savebox)
        ll.addStretch()
        splitter.addWidget(left_scroll)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(6, 0, 0, 0)
        rl.setSpacing(6)
        previewbox = QGroupBox("Preview")
        pl = QVBoxLayout(previewbox)
        prow = QHBoxLayout()
        fitbtn = QPushButton("Fit to Scale")
        fitbtn.clicked.connect(lambda: self.preview.fit_to_scale())
        refresh = QPushButton("Refresh preview")
        refresh.clicked.connect(self.refresh)
        phint = QLabel("Double-click preview = Fit to Scale")
        phint.setStyleSheet("color:#aeb6bf")
        prow.addWidget(fitbtn)
        prow.addWidget(refresh)
        prow.addStretch()
        prow.addWidget(phint)
        pl.addLayout(prow)
        self.preview = ZoomPreview()
        self.preview.imageClicked.connect(self.preview_click)
        pl.addWidget(self.preview)
        rl.addWidget(previewbox, 1)
        openbox = QGroupBox("Open saved result in Siril")
        ol = QHBoxLayout(openbox)
        self.open_complete = QPushButton("Open complete")
        self.open_overlay = QPushButton("Open overlay")
        self.open_complete.setEnabled(False); self.open_overlay.setEnabled(False)
        self.open_complete.clicked.connect(lambda: self.open_result("complete"))
        self.open_overlay.clicked.connect(lambda: self.open_result("overlay"))
        ol.addWidget(self.open_complete); ol.addWidget(self.open_overlay)
        rl.addWidget(openbox)
        splitter.addWidget(right)
        splitter.setSizes([550, 1150])

        sr = QHBoxLayout()
        self.status_label = QLabel("Ready 😎")
        self.progress = QProgressBar(); self.progress.setRange(0, 100)
        sr.addWidget(self.status_label); sr.addWidget(self.progress, 1)
        main.addLayout(sr)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(80)
        main.addWidget(self.log)

        self.resize(1720, 980)
        self.setMinimumSize(1380, 780)
        self.same_color_changed()
        self.update_color_buttons()
    # ---------- helpers ----------
    def msg(self, text):
        self.log.appendPlainText(str(text))
        QApplication.processEvents()
        try:
            self.si.log("[AG Astro Annotator] " + str(text))
        except Exception:
            pass

    def status(self, text, value=None):
        self.status_label.setText(text)
        if value is not None:
            self.progress.setValue(value)
        QApplication.processEvents()

    def update_color_buttons(self):
        self.hgrid_color_btn.setStyleSheet(
            f"QPushButton{{background:{self.hgrid_color};color:#111;border:1px solid #777;}}"
        )
        self.vgrid_color_btn.setStyleSheet(
            f"QPushButton{{background:{self.vgrid_color};color:#111;border:1px solid #777;}}"
        )
        self.label_color_btn.setStyleSheet(
            f"QPushButton{{background:{self.label_color};color:#111;border:1px solid #777;}}"
        )
        self.custom_color_btn.setStyleSheet(
            f"QPushButton{{background:{self.custom_color};color:#111;border:1px solid #777;}}"
        )

    def same_color_changed(self):
        self.label_color_btn.setEnabled(not self.same_color.isChecked())
        self.refresh()

    def pick_color(self, which):
        current = {
            "hgrid": self.hgrid_color,
            "vgrid": self.vgrid_color,
            "label": self.label_color,
            "custom": self.custom_color,
        }[which]
        c = QColorDialog.getColor(QColor(current), self)
        if not c.isValid():
            return
        if which == "hgrid":
            self.hgrid_color = c.name()
        elif which == "vgrid":
            self.vgrid_color = c.name()
        elif which == "label":
            self.label_color = c.name()
        else:
            self.custom_color = c.name()
        self.update_color_buttons()
        self.refresh()

    # ---------- load / WCS ----------
    def browse(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "Select FITS", "",
            "FITS (*.fit *.fits *.fts);;All files (*)"
        )
        if p:
            self.drop.set_file(p)

    def browse_out(self):
        p = QFileDialog.getExistingDirectory(self, "Output folder")
        if p:
            self.out.setText(p)

    def clear_input(self):
        self.path = self.original_path = None
        self.hdr = self.wcs = self.raw_rgb = self.rgb = None
        self.preview.scene_obj.clear()
        self.preview.pix_item = QGraphicsPixmapItem()
        self.preview.scene_obj.addItem(self.preview.pix_item)
        self.preview._has_image = False
        self.drop.title.setText("DROP FITS HERE")
        self.drop.path_label.setText("plate-solved or unsolved • or click Browse")
        self.wcs_state.setText("WCS: no image")
        self.objects = []
        self.catalog_objects = []
        self.table_update()
        self.status("Ready 😎", 0)

    def load_fits(self, p, keep_original=False):
        try:
            self.status("Loading FITS…", 10)
            p = Path(p)
            with fits.open(p) as hd:
                data = np.asarray(hd[0].data)
                hdr = hd[0].header.copy()

            if data.ndim == 2:
                a = data.astype(np.float32)
                rgb = np.dstack([a, a, a])
            elif data.ndim == 3 and data.shape[0] in (3, 4):
                rgb = np.moveaxis(data[:3], 0, -1).astype(np.float32)
            elif data.ndim == 3 and data.shape[-1] in (3, 4):
                rgb = data[..., :3].astype(np.float32)
            else:
                raise ValueError(f"Unsupported FITS shape: {data.shape}")

            if not keep_original or self.original_path is None:
                self.original_path = p
            self.path = p
            self.hdr = hdr
            self.raw_rgb = rgb

            try:
                w = WCS(hdr, naxis=2)
                self.wcs = w.celestial if w.has_celestial else None
            except Exception:
                self.wcs = None

            if self.wcs is None:
                self.wcs_state.setText("WCS: not solved — use Plate Solve (Siril)")
                self.wcs_state.setStyleSheet("color:#ffcc66")
            else:
                self.wcs_state.setText("WCS: ✓ celestial solution found")
                self.wcs_state.setStyleSheet("color:#7ee787")

            if not self.out.text().strip():
                base = self.original_path.parent if self.original_path else p.parent
                self.out.setText(str(base / "Annotated"))

            self.rebuild_display(fit=True)
            self.msg(f"Loaded {p.name} ({rgb.shape[1]} × {rgb.shape[0]})")

            if self.wcs is not None and hasattr(self, "show_compass") and self.show_compass.isChecked():
                self.ensure_compass_annotation(use_preset=True)

            if self.wcs is not None and hasattr(self, "catalog_auto") and self.catalog_auto.isChecked():
                try:
                    self.load_catalog(silent=True)
                except Exception as exc:
                    self.msg(f"Catalog auto-load skipped: {exc}")

            self.status("Ready 😎", 100)

        except Exception as exc:
            self.status("ERROR", 0)
            QMessageBox.critical(self, APP, str(exc))

    def plate_solve(self):
        if self.original_path is None:
            QMessageBox.warning(self, APP, "Load a FITS first.")
            return
        try:
            self.status("Plate solving with Siril…", 15)
            tmp = Path(tempfile.mkdtemp(prefix="AGANN_Solve_"))
            src = tmp / "input.fit"
            shutil.copy2(self.original_path, src)

            self.si.cmd("cd", str(tmp))
            self.si.cmd("load", "input.fit")
            self.status("Siril plate solver running…", 40)

            # Uses Siril's own scriptable plate solver and metadata/prefs.
            self.si.cmd("platesolve", "-force")
            self.status("Saving solved FITS…", 80)
            self.si.cmd("save", "solved")

            candidates = [tmp / "solved.fit", tmp / "solved.fits", tmp / "solved.fts"]
            solved = next((x for x in candidates if x.exists()), None)
            if solved is None:
                raise RuntimeError("Siril finished, but the solved FITS could not be found.")

            self.load_fits(solved, keep_original=True)
            if self.wcs is None:
                raise RuntimeError("Siril did not write a celestial WCS solution.")
            self.msg("Plate solve completed with Siril.")
            self.status("Plate solved 😎", 100)

        except Exception as exc:
            self.status("Plate solve failed", 0)
            QMessageBox.critical(
                self, APP,
                "Siril plate solving did not complete.\n\n"
                f"{exc}\n\n"
                "If the FITS has no usable center/focal-length metadata, Siril may "
                "need target coordinates / focal length in its normal Plate Solver."
            )

    # ---------- preview rendering ----------
    def linear_display(self):
        """Simple linear 8-bit preview without nonlinear stretch."""
        a = np.asarray(self.raw_rgb, dtype=np.float32)
        if a is None:
            return None
        finite = np.isfinite(a)
        if not finite.any():
            return np.zeros(a.shape, dtype=np.uint8)

        vmax = float(np.nanmax(a))
        vmin = float(np.nanmin(a))
        if vmax <= 1.5 and vmin >= -0.1:
            x = np.clip(a, 0.0, 1.0)
        elif vmax <= 65535.0 and vmin >= 0:
            x = np.clip(a / 65535.0, 0.0, 1.0)
        else:
            if vmax <= vmin:
                vmax = vmin + 1.0
            x = np.clip((a - vmin) / (vmax - vmin), 0.0, 1.0)
        return (x * 255.0).astype(np.uint8)

    def siril_autostretch_display(self):
        """
        Ask Sirilpy for Siril's own 8-bit autostretched preview.
        This is calculated only on load/toggle, not continuously.
        """
        source = self.path or self.original_path
        if source is None:
            return self.linear_display()

        fit = self.si.load_image_from_file(
            str(source),
            with_pixels=True,
            preview=True,
            linked=False
        )
        if fit is None or fit.data is None:
            raise RuntimeError("Siril did not return AutoStretch preview data.")

        data = np.asarray(fit.data)
        if data.ndim == 2:
            rgb = np.dstack([data, data, data])
        elif data.ndim == 3 and data.shape[0] in (3, 4):
            rgb = np.moveaxis(data[:3], 0, -1)
        elif data.ndim == 3 and data.shape[-1] in (3, 4):
            rgb = data[..., :3]
        else:
            raise RuntimeError(f"Unexpected Siril preview shape: {data.shape}")

        if rgb.dtype != np.uint8:
            rgb = np.clip(rgb, 0, 255).astype(np.uint8)
        return rgb

    def rebuild_display(self, checked=None, fit=False):
        if self.raw_rgb is None:
            return
        try:
            self.status("Rendering preview…", 35)
            if self.autostretch.isChecked():
                self.rgb = self.siril_autostretch_display()
                self.msg("Preview: Siril AutoStretch ON")
            else:
                self.rgb = self.linear_display()
                self.msg("Preview: AutoStretch OFF")
            self.refresh(fit=fit)
            self.status("Ready 😎", 100)
        except Exception as exc:
            self.msg("AutoStretch preview failed; using linear preview.")
            self.rgb = self.linear_display()
            self.refresh(fit=fit)
            self.status("Ready 😎", 100)

    # ---------- grid ----------
    def _choose_step_from_candidates(self, span, candidates, target_min=4.0, target_max=8.0):
        """Pick a nice step so the line count stays in a Siril-like range."""
        span = float(abs(span))
        if not np.isfinite(span) or span <= 0:
            return float(candidates[0])

        best = None
        # Prefer counts around ~5-6 lines, while staying within 4-8 when possible.
        for step in candidates:
            step = float(step)
            if step <= 0:
                continue
            count = span / step
            score = abs(count - 5.5)
            in_range = (target_min <= count <= target_max)
            # in_range gets priority, then closeness to the 5.5 sweet spot, then slightly coarser grids
            rank = (0 if in_range else 1, round(score, 6), -step)
            if best is None or rank < best[0]:
                best = (rank, step)

        return float(best[1] if best else candidates[0])

    def _auto_grid_steps(self, r0, r1, d0, d1, dec_center):
        """Choose independent RA/Dec intervals close to Siril's automatic grid."""
        # RA coordinates are expressed as time. 1 hour RA = 15 degrees, so
        # one degree RA = 4 minutes of RA time. Siril's labels use nice time
        # steps such as 1m, 2m, 5m, 10m ... regardless of declination.
        ra_span_time_min = abs(float(r1) - float(r0)) * 4.0
        dec_span_arcmin = abs(float(d1) - float(d0)) * 60.0

        ra_candidates_min = [1, 2, 5, 10, 15, 30, 60]
        dec_candidates_min = [5, 10, 15, 30, 60, 120]

        ra_step_min = self._choose_step_from_candidates(
            ra_span_time_min, ra_candidates_min, target_min=4.0, target_max=7.5
        )
        dec_step_min = self._choose_step_from_candidates(
            dec_span_arcmin, dec_candidates_min, target_min=4.0, target_max=7.5
        )

        # Convert RA minutes of TIME to coordinate degrees.
        ra_step_deg = ra_step_min * 15.0 / 60.0
        dec_step_deg = dec_step_min / 60.0
        return ra_step_deg, dec_step_deg

    def spacing_value(self):
        t = self.spacing.currentText()
        if t != "Siril Auto":
            return float(t.replace("°", ""))
        if self.wcs is None or self.rgb is None:
            return 1.0
        h, w = self.rgb.shape[:2]
        sky = self.wcs.pixel_to_world(
            np.array([0, w - 1, w - 1, 0]),
            np.array([0, 0, h - 1, h - 1])
        )
        center = self.wcs.pixel_to_world(w / 2, h / 2)
        fov = center.separation(sky).deg.max() * 2
        for z in (0.1, 0.25, 0.5, 1, 2, 5, 10):
            if fov / z <= 8:
                return z
        return 10

    def grid_lines(self):
        """
        Build WCS grid polylines.

        Manual spacing modes keep the old sky-cell aspect logic.
        "Siril Auto" chooses independent RA/Dec steps from common astronomical
        intervals so the automatic grid density more closely matches Siril.
        """
        if self.wcs is None:
            return [], [], [], []

        h, w = self.rgb.shape[:2]
        sky = self.wcs.pixel_to_world(
            np.array([0, w - 1, w - 1, 0]),
            np.array([0, 0, h - 1, h - 1])
        )
        center = self.wcs.pixel_to_world(w / 2, h / 2)
        ra_center = center.ra.deg
        dec_center = float(center.dec.deg)
        rav = sky.ra.wrap_at((ra_center + 180) * u.deg).deg
        r0, r1 = np.nanmin(rav), np.nanmax(rav)
        d0, d1 = np.nanmin(sky.dec.deg), np.nanmax(sky.dec.deg)

        mode = self.grid_aspect.currentText() if hasattr(self, 'grid_aspect') else 'Legacy'

        if self.spacing.currentText() == 'Siril Auto':
            ra_step, dec_step = self._auto_grid_steps(r0, r1, d0, d1, dec_center)
        else:
            dec_step = self.spacing_value()
            cosdec = max(0.08, abs(math.cos(math.radians(dec_center))))
            if mode == '1×1 (Siril-like)':
                ra_step = dec_step / cosdec
            elif mode == '2×1':
                ra_step = 2.0 * dec_step / cosdec
            elif mode == '1×2':
                ra_step = 0.5 * dec_step / cosdec
            else:
                ra_step = dec_step

        def ticks(a, b, step):
            return np.arange(
                math.floor(a / step) * step,
                math.ceil(b / step) * step + step * 0.5,
                step
            )

        def format_ra(ra_deg):
            hours = (float(ra_deg) / 15.0) % 24.0
            hh = int(math.floor(hours))
            mm = int(round((hours - hh) * 60.0))
            if mm >= 60:
                mm -= 60
                hh = (hh + 1) % 24
            return f"{hh:02d}h{mm:02d}m"

        def format_dec(dec_deg):
            sign = '+' if dec_deg >= 0 else '-'
            v = abs(float(dec_deg))
            dd = int(math.floor(v))
            mm = int(round((v - dd) * 60.0))
            if mm >= 60:
                mm -= 60
                dd += 1
            return f"{sign}{dd:02d}°{mm:02d}'"

        def choose_siril_anchor(visible_pts):
            """Prefer the bottom or right image border, like Siril's grid labels."""
            if not visible_pts:
                return None

            dp = [(float(x), float((h - 1) - y)) for x, y in visible_pts]

            # Siril normally labels on the two clean presentation axes:
            # bottom for near-vertical lines, right for near-horizontal lines.
            bottom_pt = max(dp, key=lambda p: p[1])
            right_pt = max(dp, key=lambda p: p[0])
            bottom_dist = max(0.0, (h - 1) - bottom_pt[1])
            right_dist = max(0.0, (w - 1) - right_pt[0])

            if bottom_dist <= right_dist:
                x, yd = bottom_pt
                edge = 'bottom'
            else:
                x, yd = right_pt
                edge = 'right'

            # convert display Y back to raw FITS/WCS Y for the existing pipeline
            return float(x), float((h - 1) - yd), edge

        vsegs, hsegs, ra_labels, dec_labels = [], [], [], []

        ds = np.linspace(d0, d1, 600)
        for ra in ticks(r0, r1, ra_step):
            q = SkyCoord(np.full_like(ds, ra) * u.deg, ds * u.deg)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                with np.errstate(all="ignore"):
                    px, py = self.wcs.world_to_pixel(q)
            pts = [(float(x), float(y)) for x, y in zip(px, py)
                   if np.isfinite(x + y)
                   and -180 < x < w + 180 and -180 < y < h + 180]
            if len(pts) < 2:
                continue
            vsegs.append(pts)
            visible = [(x, y) for x, y in pts if 0 <= x < w and 0 <= y < h]
            anchor = choose_siril_anchor(visible)
            if anchor:
                ra_labels.append((anchor[0], anchor[1], format_ra(ra), 'v', anchor[2]))

        rs = np.linspace(r0, r1, 600)
        for dec in ticks(d0, d1, dec_step):
            q = SkyCoord(rs * u.deg, np.full_like(rs, dec) * u.deg)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                with np.errstate(all="ignore"):
                    px, py = self.wcs.world_to_pixel(q)
            pts = [(float(x), float(y)) for x, y in zip(px, py)
                   if np.isfinite(x + y)
                   and -180 < x < w + 180 and -180 < y < h + 180]
            if len(pts) < 2:
                continue
            hsegs.append(pts)
            visible = [(x, y) for x, y in pts if 0 <= x < w and 0 <= y < h]
            anchor = choose_siril_anchor(visible)
            if anchor:
                dec_labels.append((anchor[0], anchor[1], format_dec(dec), 'h', anchor[2]))

        return vsegs, hsegs, ra_labels, dec_labels

    # ---------- overlay / labels ----------
    def offset_label_xy(self, draw, x, y, text, fnt, pad=10):
        # Object/catalog labels use one clean fixed placement. Grid-coordinate
        # labels are rendered separately in the Siril-style border positions.
        bbox = draw.textbbox((0, 0), text, font=fnt)
        th = bbox[3] - bbox[1]
        return x + pad, y - th / 2

    def label_xy(self, draw, obj, text, fnt):
        pad = (obj.get("size", 24) / 2 + 10) if obj.get("custom") else 10
        return self.offset_label_xy(draw, obj["x"], obj["y"], text, fnt, pad)

    def draw_compass(self, d, w, h):
        if self.wcs is None or not self.show_compass.isChecked():
            return

        box = 150
        margin = 30
        pos = self.compass_pos.currentText()
        if pos == "Top Left":
            x0, y0 = margin, margin
        elif pos == "Top Right":
            x0, y0 = w - margin - box, margin
        elif pos == "Bottom Left":
            x0, y0 = margin, h - margin - box
        else:
            x0, y0 = w - margin - box, h - margin - box

        # Semi-transparent badge guarantees visibility even on dense star fields.
        d.rounded_rectangle(
            (x0, y0, x0 + box, y0 + box), radius=18,
            fill=(0, 0, 0, 105), outline=(255, 255, 255, 150), width=2
        )
        xc, yc = x0 + box / 2, y0 + box / 2

        try:
            p0 = self.wcs.pixel_to_world(xc, yc)
            sep = 0.05 * u.deg
            pn = p0.directional_offset_by(0*u.deg, sep)
            pe = p0.directional_offset_by(90*u.deg, sep)
            nx, ny = self.wcs.world_to_pixel(pn)
            ex, ey = self.wcs.world_to_pixel(pe)
            nv = np.array([float(nx-xc), float(ny-yc)], dtype=float)
            ev = np.array([float(ex-xc), float(ey-yc)], dtype=float)
            def unit(v, fallback):
                n = np.linalg.norm(v)
                return v/n if np.isfinite(n) and n > 1e-6 else np.array(fallback, dtype=float)
            nv = unit(nv, [0,-1]) * 45
            ev = unit(ev, [1,0]) * 45
        except Exception:
            nv = np.array([0.0, -45.0])
            ev = np.array([45.0, 0.0])

        col = (255, 255, 255, 255)
        shadow = (0, 0, 0, 255)
        width = 5
        # shadow + main arrows
        for v in (nv, ev):
            d.line((xc+2, yc+2, xc+v[0]+2, yc+v[1]+2), fill=shadow, width=width+2)
            d.line((xc, yc, xc+v[0], yc+v[1]), fill=col, width=width)
        d.ellipse((xc-5, yc-5, xc+5, yc+5), fill=col)

        f = pil_font(30)
        d.text((xc+nv[0]-11, yc+nv[1]-31), 'N', fill=shadow, font=f)
        d.text((xc+nv[0]-13, yc+nv[1]-33), 'N', fill=col, font=f)
        d.text((xc+ev[0]+5, yc+ev[1]-16), 'E', fill=shadow, font=f)
        d.text((xc+ev[0]+3, yc+ev[1]-18), 'E', fill=col, font=f)

    def overlay(self):
        if self.rgb is None:
            raise ValueError("Load a FITS first.")
        h, w = self.rgb.shape[:2]
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)

        fnt = pil_font(int(self.font_size.get()))
        grid_font = pil_font(max(10, min(220, int(self.font_size.get() * 0.55))))

        if self.grid.isChecked() and self.wcs is not None:
            vsegs, hsegs, ra_labels, dec_labels = self.grid_lines()
            lw = max(1, int(round(self.grid_width.get())))
            hc = rgba(self.hgrid_color, int(255 * self.grid_opacity.get() / 100))
            vc = rgba(self.vgrid_color, int(255 * self.grid_opacity.get() / 100))
            for pts in hsegs:
                d.line(pts, fill=hc, width=lw)
            for pts in vsegs:
                d.line(pts, fill=vc, width=lw)

            if self.labels.isChecked():
                for x, y, text, kind in ra_labels + dec_labels:
                    if self.same_color.isChecked():
                        col = vc if kind == "v" else hc
                    else:
                        col = rgba(self.label_color, 255)

                    bbox = d.textbbox((0, 0), text, font=grid_font)
                    tw = bbox[2] - bbox[0]
                    th = bbox[3] - bbox[1]

                    # Center the label on the selected sample point of its own
                    # WCS grid line. Offset it slightly perpendicular to reduce
                    # line/text overlap.
                    if kind == "v":
                        tx = x + 7
                        ty = y - th / 2
                    else:
                        tx = x - tw / 2
                        ty = y - th - 7

                    d.text((tx+1, ty+1), text, fill=(0,0,0,225), font=grid_font)
                    d.text((tx, ty), text, fill=col, font=grid_font)

        if self.labels.isChecked():
            for obj in self.objects:
                x, y = obj['x'], obj['y']
                if not (0 <= x < w and 0 <= y < h):
                    continue
                if obj.get('custom'):
                    marker_col = rgba(obj.get('marker_color', self.custom_color), 255)
                    size = obj.get('size', 50)
                    half = size / 2
                    shape = obj.get('shape', 'Box')
                    if shape == 'Box':
                        d.rectangle((x-half, y-half, x+half, y+half), outline=marker_col, width=2)
                    elif shape == 'Circle':
                        d.ellipse((x-half, y-half, x+half, y+half), outline=marker_col, width=2)
                    elif shape == 'Crosshair':
                        d.line((x-half, y, x+half, y), fill=marker_col, width=2)
                        d.line((x, y-half, x, y+half), fill=marker_col, width=2)

                # Catalogue marker style can be chosen like Custom objects.
                if obj.get("type") == "Catalog":
                    style = self.catalog_marker_style.currentText()
                    auto_size = obj.get("catalog_marker_px")
                    size = float(auto_size) if auto_size else float(self.catalog_marker_size.get())
                    size = max(8.0, size)
                    half = size / 2.0
                    marker_col = rgba(self.label_color, 230)
                    mw = max(2, min(12, int(round(self.grid_width.get()/2))))

                    if style == "Auto (object size)":
                        # Siril-like automatic circle when diameter exists; otherwise fallback circle.
                        d.ellipse((x-half, y-half, x+half, y+half), outline=marker_col, width=mw)
                    elif style == "Circle":
                        d.ellipse((x-half, y-half, x+half, y+half), outline=marker_col, width=mw)
                    elif style == "Box":
                        d.rectangle((x-half, y-half, x+half, y+half), outline=marker_col, width=mw)
                    elif style == "Crosshair":
                        d.line((x-half, y, x+half, y), fill=marker_col, width=mw)
                        d.line((x, y-half, x, y+half), fill=marker_col, width=mw)
                    # Text only: intentionally no marker.

                name = obj.get('name', '').strip()
                if not name:
                    continue
                if obj.get("type") == "Catalog":
                    local_font = pil_font(int(self.catalog_font_size.get()))
                else:
                    local_font = pil_font(int(obj.get('text_size', self.font_size.get())))
                tx, ty = self.label_xy(d, obj, name, local_font)
                d.text((tx+1, ty+1), name, fill=(0,0,0,225), font=local_font)
                d.text((tx, ty), name, fill=rgba(self.label_color, 255), font=local_font)

        self.draw_compass(d, w, h)
        return im
    # ---------- catalog / custom ----------
    def parse_coord(self, ra, dec):
        ra, dec = ra.strip(), dec.strip()
        if any(c in ra.lower() for c in (":", "h", "m", "s")):
            return SkyCoord(ra, dec, unit=(u.hourangle, u.deg))
        return SkyCoord(float(ra) * u.deg, float(dec) * u.deg)

    def preview_click(self, x, y):
        # Preview is vertically flipped to match Siril's GUI. Convert the click
        # back to the original FITS/WCS pixel convention before storing it.
        if self.rgb is not None:
            y_wcs = (self.rgb.shape[0] - 1) - y
        else:
            y_wcs = y
        self.cx.setValue(x)
        self.cy.setValue(y_wcs)
        if self.wcs is not None:
            q = self.wcs.pixel_to_world(x, y_wcs)
            self.ra.setText(q.ra.to_string(unit=u.hour, sep=":", precision=2))
            self.dec.setText(q.dec.to_string(unit=u.deg, sep=":", precision=1, alwayssign=True))

    def add_xy(self):
        if self.rgb is None:
            return
        x, y = self.cx.value(), self.cy.value()
        ra_s = dec_s = ""
        if self.wcs is not None:
            q = self.wcs.pixel_to_world(x, y)
            ra_s = q.ra.to_string(unit=u.hour, sep=":", precision=2)
            dec_s = q.dec.to_string(unit=u.deg, sep=":", precision=1, alwayssign=True)
        self.objects.append({
            'name': self.custom_text.text() or 'Custom object',
            'x': x, 'y': y,
            'ra': ra_s, 'dec': dec_s,
            'shape': self.shape.currentText(),
            'size': int(self.marker_size.get()),
            'text_size': int(self.custom_text_size.get()),
            'marker_color': self.custom_color,
            'custom': True,
        })
        self.table_update(); self.refresh()

    def add_radec(self):
        if self.wcs is None:
            QMessageBox.warning(self, APP, 'Plate-solve the FITS first.')
            return
        try:
            q = self.parse_coord(self.ra.text(), self.dec.text())
            x, y = self.wcs.world_to_pixel(q)
            self.cx.setValue(float(x))
            self.cy.setValue(float(y))
            self.add_xy()
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def add_custom(self):
        if self.ra.text().strip() and self.dec.text().strip():
            self.add_radec()
        else:
            self.add_xy()

    def import_csv(self):
        if self.wcs is None:
            QMessageBox.warning(self, APP, 'Plate-solve the FITS first.')
            return
        p, _ = QFileDialog.getOpenFileName(self, 'Import CSV', '', 'CSV (*.csv);;All files (*)')
        if not p:
            return
        try:
            count = 0
            with open(p, encoding='utf-8-sig', newline='') as f:
                reader = csv.DictReader(f)
                fm = {x.lower(): x for x in (reader.fieldnames or [])}
                nk = fm.get('name') or fm.get('object')
                rk = fm.get('ra')
                dk = fm.get('dec') or fm.get('declination')
                if not (nk and rk and dk):
                    raise ValueError('CSV requires Name, RA, Dec columns')
                for row in reader:
                    q = self.parse_coord(row[rk], row[dk])
                    x, y = self.wcs.world_to_pixel(q)
                    self.objects.append({
                        'name': row[nk], 'x': float(x), 'y': float(y),
                        'ra': row[rk], 'dec': row[dk],
                        'shape': 'CSV', 'type': 'CSV', 'custom': False,
                    })
                    count += 1
            self.msg(f'Imported {count} CSV labels.')
            self.table_update(); self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def field_center_radius(self):
        h, w = self.rgb.shape[:2]
        center = self.wcs.pixel_to_world(w / 2, h / 2)
        corners = self.wcs.pixel_to_world(
            np.array([0, w-1, w-1, 0]),
            np.array([0, 0, h-1, h-1])
        )
        radius = max(center.separation(c).deg for c in corners)
        return center, max(0.05, radius)

    def clear_catalog(self):
        self.objects = [o for o in self.objects if o.get("type") != "Catalog"]
        self.catalog_objects = []
        self.table_update()
        self.refresh()

    @staticmethod
    def _norm_col(name):
        return re.sub(r"[^a-z0-9]+", "", str(name).strip().lower())

    def _find_catalog_files(self, kind):
        """
        Locate Siril annotation catalogues.

        v1.8 bundles the official Siril 1.4.4 CSV files beside the script so
        catalogue support no longer depends on the user's Siril install path.
        Local Siril directories remain as fallbacks.
        """
        exact = {
            "Messier": "messier.csv",
            "NGC": "ngc.csv",
            "IC": "ic.csv",
            "Sh2": "sh2.csv",
            "LdN": "ldn.csv",
        }[kind]

        hits = []
        seen = set()

        for root in self.catalog_dirs:
            try:
                candidate = root / exact
                if candidate.is_file():
                    key = str(candidate.resolve()).lower()
                    if key not in seen:
                        hits.append(candidate)
                        seen.add(key)
                    # Bundled exact hit is all we need; avoid duplicate labels
                    # from a second copy of the same Siril catalogue.
                    if root.name == "AG_Astro_Annotator_catalogue":
                        return hits
            except Exception:
                pass

        return hits

    def _read_siril_catalog(self, path, catalog_name):
        """
        Read a Siril annotation CSV generically.

        Known/accepted column semantics:
        name, ra, dec, diameter, mag, type.
        RA/Dec can be decimal degrees or sexagesimal.
        """
        items = []
        try:
            # Siril catalogue files are CSV; tolerate comments and alternate separators.
            raw = path.read_text(encoding="utf-8-sig", errors="replace")
            lines = [ln for ln in raw.splitlines() if ln.strip() and not ln.lstrip().startswith("#")]
            if not lines:
                return items

            sample = "\n".join(lines[:8])
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except Exception:
                dialect = csv.excel

            reader = csv.DictReader(lines, dialect=dialect)
            if not reader.fieldnames:
                return items

            cmap = {self._norm_col(c): c for c in reader.fieldnames}

            def col(*names):
                for n in names:
                    hit = cmap.get(self._norm_col(n))
                    if hit:
                        return hit
                return None

            name_col = col("name", "object", "id", "designation", "mainid")
            ra_col = col("ra", "raj2000", "radeg", "rightascension")
            dec_col = col("dec", "dej2000", "decdeg", "declination")
            diam_col = col("diameter", "diam", "size", "majoraxis", "majaxis")
            type_col = col("type", "objecttype", "otype")

            if not ra_col or not dec_col:
                return items

            for row in reader:
                try:
                    ra_raw = str(row.get(ra_col, "")).strip()
                    dec_raw = str(row.get(dec_col, "")).strip()
                    if not ra_raw or not dec_raw:
                        continue

                    # Prefer decimal degrees, otherwise sexagesimal.
                    try:
                        q = SkyCoord(float(ra_raw)*u.deg, float(dec_raw)*u.deg, frame="icrs")
                    except Exception:
                        q = self.parse_coord(ra_raw, dec_raw)

                    name = str(row.get(name_col, "")).strip() if name_col else ""
                    if not name:
                        name = catalog_name

                    diameter_arcmin = None
                    if diam_col:
                        try:
                            diameter_arcmin = float(str(row.get(diam_col, "")).strip())
                            if not np.isfinite(diameter_arcmin) or diameter_arcmin <= 0:
                                diameter_arcmin = None
                        except Exception:
                            diameter_arcmin = None

                    items.append({
                        "name": name,
                        "coord": q,
                        "diameter_arcmin": diameter_arcmin,
                        "catalog": catalog_name,
                        "otype": str(row.get(type_col, "")).strip() if type_col else "",
                    })
                except Exception:
                    continue
        except Exception as exc:
            self.msg(f"Could not read {path.name}: {exc}")

        return items

    def _angular_diameter_to_pixels(self, coord, diameter_arcmin):
        """
        Convert angular diameter to local pixel diameter using the WCS itself.
        This also behaves correctly for images with rotation/skew.
        """
        if not diameter_arcmin or diameter_arcmin <= 0:
            return None
        try:
            x0, y0 = self.wcs.world_to_pixel(coord)
            sep = (diameter_arcmin / 2.0) * u.arcmin
            q2 = coord.directional_offset_by(90*u.deg, sep)
            x1, y1 = self.wcs.world_to_pixel(q2)
            radius = math.hypot(float(x1-x0), float(y1-y0))
            if np.isfinite(radius) and radius > 0:
                return radius * 2.0
        except Exception:
            pass
        return None

    def load_catalog(self, checked=False, silent=False):
        if self.wcs is None or self.rgb is None:
            if not silent:
                QMessageBox.warning(self, APP, "Load and plate-solve a FITS first.")
            return

        selected = []
        if self.cat_messier.isChecked():
            selected.append("Messier")
        if self.cat_ngc.isChecked():
            selected.append("NGC")
        if self.cat_ic.isChecked():
            selected.append("IC")
        if self.cat_sh2.isChecked():
            selected.append("Sh2")
        if self.cat_ldn.isChecked():
            selected.append("LdN")

        if not selected:
            if not silent:
                QMessageBox.information(self, APP, "Select at least one catalog.")
            return

        self.status("Loading Siril offline catalogs…", 25)
        self.clear_catalog()

        h, w = self.rgb.shape[:2]
        count = 0
        missing = []

        # No arbitrary "Max objects": every selected catalogue is scanned and
        # only objects whose WCS position lies inside this image are retained.
        for kind in selected:
            files = self._find_catalog_files(kind)
            if not files:
                missing.append(kind)
                continue

            # Deduplicate aliases/files that may exist after upgrades.
            seen = set()

            for f in files:
                for item in self._read_siril_catalog(f, kind):
                    key = (
                        item["name"].strip().upper(),
                        round(item["coord"].ra.deg, 6),
                        round(item["coord"].dec.deg, 6),
                    )
                    if key in seen:
                        continue
                    seen.add(key)

                    try:
                        x, y = self.wcs.world_to_pixel(item["coord"])
                    except Exception:
                        continue

                    if not (np.isfinite(x) and np.isfinite(y)):
                        continue
                    if not (0 <= x < w and 0 <= y < h):
                        continue

                    marker_px = self._angular_diameter_to_pixels(
                        item["coord"], item["diameter_arcmin"]
                    )

                    self.objects.append({
                        "name": item["name"],
                        "x": float(x),
                        "y": float(y),
                        "ra": item["coord"].ra.to_string(unit=u.hourangle, sep=":", precision=2),
                        "dec": item["coord"].dec.to_string(unit=u.deg, sep=":", precision=1, alwayssign=True),
                        "shape": "Catalog",
                        "type": "Catalog",
                        "catalog": kind,
                        "catalog_marker_px": marker_px,
                        "custom": False,
                    })
                    count += 1

        self.catalog_objects = [o for o in self.objects if o.get("type") == "Catalog"]
        self.table_update()
        self.refresh()

        status_text = f"Loaded {count} Siril catalog objects"
        if missing:
            status_text += " • catalogue files missing: " + ", ".join(missing)
        self.catalog_status.setText(status_text)
        self.msg(status_text)
        self.status("Ready 😎", 100)

        if count == 0 and not silent:
            QMessageBox.information(
                self,
                APP,
                "No selected Siril catalogue objects fall inside this image.\n\n"
                f"Catalog folder:\n{self.catalog_dir}"
            )

    def get_compass_annotation(self):
        for obj in self.objects:
            if obj.get("type") == "Compass":
                return obj
        return None

    def compass_preset_raw_xy(self):
        if self.rgb is None:
            return 0.0, 0.0
        h, w = self.rgb.shape[:2]
        box = float(self.compass_size.get())
        margin = max(12.0, box * 0.08)
        pos = self.compass_pos.currentText()
        if pos == "Top Left":
            dx, dy = margin + box/2, margin + box/2
        elif pos == "Top Right":
            dx, dy = w - margin - box/2, margin + box/2
        elif pos == "Bottom Left":
            dx, dy = margin + box/2, h - margin - box/2
        else:
            dx, dy = w - margin - box/2, h - margin - box/2
        # display -> raw FITS/WCS
        return float(dx), float((h - 1) - dy)

    def ensure_compass_annotation(self, use_preset=False):
        if self.rgb is None:
            return None
        obj = self.get_compass_annotation()
        if obj is None:
            x, y = self.compass_preset_raw_xy()
            obj = {
                "name": "Compass",
                "x": x,
                "y": y,
                "ra": "",
                "dec": "",
                "type": "Compass",
                "custom": False,
            }
            self.objects.append(obj)
        elif use_preset:
            obj["x"], obj["y"] = self.compass_preset_raw_xy()

        if self.wcs is not None:
            try:
                q = self.wcs.pixel_to_world(obj["x"], obj["y"])
                obj["ra"] = q.ra.to_string(unit=u.hourangle, sep=":", precision=2)
                obj["dec"] = q.dec.to_string(unit=u.deg, sep=":", precision=1, alwayssign=True)
            except Exception:
                pass
        self.table_update()
        return obj

    def compass_visibility_changed(self, checked):
        if checked:
            self.ensure_compass_annotation(use_preset=False)
        else:
            self.objects = [o for o in self.objects if o.get("type") != "Compass"]
            self.table_update()
        self.refresh()

    def compass_preset_changed(self):
        if self.show_compass.isChecked():
            self.ensure_compass_annotation(use_preset=True)
            self.refresh()

    def annotation_selection_changed(self):
        r = self.table.currentRow()
        if r < 0 or r >= len(self.objects):
            return
        o = self.objects[r]
        self.ann_x.setValue(float(o.get("x", 0)))
        self.ann_y.setValue(float(o.get("y", 0)))
        self.ann_ra.setText(str(o.get("ra", "")))
        self.ann_dec.setText(str(o.get("dec", "")))

    def apply_annotation_position(self):
        r = self.table.currentRow()
        if r < 0 or r >= len(self.objects):
            QMessageBox.information(self, APP, "Select an annotation first.")
            return

        o = self.objects[r]
        try:
            new_x = float(self.ann_x.value())
            new_y = float(self.ann_y.value())
            old_x = float(o.get("x", 0.0))
            old_y = float(o.get("y", 0.0))

            ra_text = self.ann_ra.text().strip()
            dec_text = self.ann_dec.text().strip()
            old_ra = str(o.get("ra", "")).strip()
            old_dec = str(o.get("dec", "")).strip()

            xy_changed = abs(new_x - old_x) > 0.005 or abs(new_y - old_y) > 0.005
            radec_changed = (ra_text != old_ra or dec_text != old_dec)

            # Important for Compass: the fields are pre-filled with RA/Dec.
            # In older builds that made RA/Dec always win, so editing X/Y had
            # no visible effect. Now the field the user actually changed wins.
            if xy_changed or not (radec_changed and self.wcs is not None and ra_text and dec_text):
                o["x"], o["y"] = new_x, new_y
                if self.wcs is not None:
                    q = self.wcs.pixel_to_world(o["x"], o["y"])
                    o["ra"] = q.ra.to_string(unit=u.hourangle, sep=":", precision=2)
                    o["dec"] = q.dec.to_string(unit=u.deg, sep=":", precision=1, alwayssign=True)
            else:
                q = self.parse_coord(ra_text, dec_text)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    x, y = self.wcs.world_to_pixel(q)
                o["x"], o["y"] = float(x), float(y)
                o["ra"], o["dec"] = ra_text, dec_text

            self.table_update()
            self.table.selectRow(r)
            self.annotation_selection_changed()
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def table_update(self):
        self.table.setRowCount(len(self.objects))
        for r, o in enumerate(self.objects):
            vals = [
                o.get("name", ""),
                f"{o.get('x', 0):.1f}",
                f"{o.get('y', 0):.1f}",
                o.get("ra", ""),
                o.get("dec", ""),
                o.get("type", o.get("shape", "")),
            ]
            for c, v in enumerate(vals):
                self.table.setItem(r, c, QTableWidgetItem(str(v)))

    def remove_selected(self):
        r = self.table.currentRow()
        if r >= 0 and r < len(self.objects):
            was_compass = self.objects[r].get("type") == "Compass"
            self.objects.pop(r)
            if was_compass and hasattr(self, "show_compass"):
                self.show_compass.blockSignals(True)
                self.show_compass.setChecked(False)
                self.show_compass.blockSignals(False)
            self.table_update()
            self.refresh()

    def clear_annotations(self):
        self.objects.clear()
        if hasattr(self, "show_compass"):
            self.show_compass.blockSignals(True)
            self.show_compass.setChecked(False)
            self.show_compass.blockSignals(False)
        self.table_update()
        self.refresh()

    # ---------- preview ----------
    def _display_xy(self, x, y):
        if self.rgb is None:
            return float(x), float(y)
        h = self.rgb.shape[0]
        return float(x), float((h - 1) - y)

    def _display_pts(self, pts):
        return [self._display_xy(x, y) for x, y in pts]

    def draw_display_compass(self, d, w, h):
        if self.wcs is None or not self.show_compass.isChecked():
            return
        if self.get_compass_annotation() is None:
            return

        box = int(round(self.compass_size.get()))
        box = max(100, min(box, max(100, min(w, h) - 20)))
        margin = max(10, int(box * 0.06))
        pos = self.compass_pos.currentText()
        if pos == "Top Left":
            x0, y0 = margin, margin
        elif pos == "Top Right":
            x0, y0 = w - margin - box, margin
        elif pos == "Bottom Left":
            x0, y0 = margin, h - margin - box
        else:
            x0, y0 = w - margin - box, h - margin - box

        # Position is stored as an Annotation in raw FITS/WCS pixels.
        comp_obj = self.get_compass_annotation()
        if comp_obj is not None:
            xc, yc = self._display_xy(comp_obj.get("x", w/2), comp_obj.get("y", h/2))
        else:
            x0 = max(4, min(x0, w - box - 4))
            y0 = max(4, min(y0, h - box - 4))
            xc, yc = x0 + box / 2.0, y0 + box / 2.0

        try:
            raw_x, raw_y = w / 2.0, h / 2.0
            p0 = self.wcs.pixel_to_world(raw_x, raw_y)
            sep = 0.03 * u.deg
            pn = p0.directional_offset_by(0 * u.deg, sep)
            pe = p0.directional_offset_by(90 * u.deg, sep)
            nx, ny = self.wcs.world_to_pixel(pn)
            ex, ey = self.wcs.world_to_pixel(pe)
            nv = np.array([float(nx - raw_x), -float(ny - raw_y)], dtype=float)
            ev = np.array([float(ex - raw_x), -float(ey - raw_y)], dtype=float)

            def unit(v, fb):
                n = np.linalg.norm(v)
                return v / n if np.isfinite(n) and n > 1e-8 else np.array(fb, dtype=float)

            L = box * 0.28
            nv = unit(nv, [0, -1]) * L
            ev = unit(ev, [1, 0]) * L
        except Exception:
            L = box * 0.28
            nv = np.array([0.0, -L])
            ev = np.array([L, 0.0])

        fg_a = int(255 * self.compass_opacity.get() / 100.0)
        sh_a = int(255 * self.compass_bg_opacity.get() / 100.0)
        north_col = (255, 60, 60, fg_a)
        east_col = (255, 255, 255, fg_a)
        shadow = (0, 0, 0, sh_a)
        lw = max(3, int(box * 0.018))
        ah = max(10, int(box * 0.05))

        def draw_arrow(vec, col):
            x1, y1 = xc + vec[0], yc + vec[1]
            # shadow
            d.line((xc + 1, yc + 1, x1 + 1, y1 + 1), fill=shadow, width=lw + 2)
            # shaft
            d.line((xc, yc, x1, y1), fill=col, width=lw)
            # arrow head
            n = np.linalg.norm(vec)
            if n <= 1e-8:
                return
            uvec = vec / n
            perp = np.array([-uvec[1], uvec[0]])
            p1 = (x1, y1)
            p2 = (x1 - uvec[0] * ah + perp[0] * ah * 0.55,
                  y1 - uvec[1] * ah + perp[1] * ah * 0.55)
            p3 = (x1 - uvec[0] * ah - perp[0] * ah * 0.55,
                  y1 - uvec[1] * ah - perp[1] * ah * 0.55)
            d.polygon([(p1[0] + 1, p1[1] + 1), (p2[0] + 1, p2[1] + 1), (p3[0] + 1, p3[1] + 1)], fill=shadow)
            d.polygon([p1, p2, p3], fill=col)

        draw_arrow(nv, north_col)
        draw_arrow(ev, east_col)

        fs = max(18, int(box * 0.15))
        f = pil_font(fs)

        # Letters below their respective arrow tips, clear of the shafts.
        def below_tip(vec, text):
            tx = xc + vec[0]
            ty = yc + vec[1]
            bb = d.textbbox((0,0), text, font=f)
            tw = bb[2]-bb[0]
            return (tx - tw/2, ty + max(8, int(fs*0.28)))

        npos = below_tip(nv, "N")
        epos = below_tip(ev, "E")
        for text, posxy, col in (("N", npos, north_col), ("E", epos, east_col)):
            tx, ty = posxy
            d.text((tx + 1, ty + 1), text, fill=shadow, font=f)
            d.text((tx, ty), text, fill=col, font=f)

    def draw_rotated_text(self, base_image, xy, text, font, fill, angle=90, shadow=True):
        """
        Draw anti-aliased rotated text without clipping glyph ascenders/descenders.

        Pillow TrueType textbbox can have negative left/top bearings, so the
        tile origin must compensate for bbox[0]/bbox[1].
        """
        tmp_draw = ImageDraw.Draw(base_image)
        bb = tmp_draw.textbbox((0, 0), text, font=font, stroke_width=0)
        pad = max(12, int(getattr(font, "size", 20) * 0.18))
        shadow_px = max(2, int(getattr(font, "size", 20) * 0.025))

        tw = max(1, int(math.ceil(bb[2] - bb[0])))
        th = max(1, int(math.ceil(bb[3] - bb[1])))

        tile = Image.new(
            "RGBA",
            (tw + pad*2 + shadow_px*2, th + pad*2 + shadow_px*2),
            (0, 0, 0, 0)
        )
        td = ImageDraw.Draw(tile)

        # Compensate for negative font bearings.
        ox = pad - bb[0]
        oy = pad - bb[1]

        if shadow:
            td.text(
                (ox + shadow_px, oy + shadow_px),
                text, fill=(0, 0, 0, 225), font=font
            )
        td.text((ox, oy), text, fill=fill, font=font)

        rot = tile.rotate(
            angle,
            expand=True,
            resample=Image.Resampling.BICUBIC
        )
        x, y = int(round(xy[0])), int(round(xy[1]))
        base_image.alpha_composite(rot, (x, y))
        return rot.size

    def display_overlay(self):
        """Render directly in Siril display coordinates so text is never mirrored."""
        if self.rgb is None:
            raise ValueError("Load a FITS first.")
        h,w=self.rgb.shape[:2]
        im=Image.new("RGBA",(w,h),(0,0,0,0)); d=ImageDraw.Draw(im)
        grid_font=pil_font(max(10,min(220,int(self.font_size.get()*0.55))))

        if self.grid.isChecked() and self.wcs is not None:
            vsegs,hsegs,ra_labels,dec_labels=self.grid_lines()
            lw=max(1,int(round(self.grid_width.get())))
            hc=rgba(self.hgrid_color,int(255*self.grid_opacity.get()/100))
            vc=rgba(self.vgrid_color,int(255*self.grid_opacity.get()/100))
            for pts in hsegs: d.line(self._display_pts(pts),fill=hc,width=lw)
            for pts in vsegs: d.line(self._display_pts(pts),fill=vc,width=lw)
            if self.labels.isChecked():
                margin = 8

                def nearest_grid_line(kind, raw_x, raw_y):
                    source = vsegs if kind == 'v' else hsegs
                    dx, dy = self._display_xy(raw_x, raw_y)
                    best_line = None
                    best_dist = None
                    for pts in source:
                        dpts = self._display_pts(pts)
                        if not dpts:
                            continue
                        dist = min((px-dx)*(px-dx) + (py-dy)*(py-dy) for px,py in dpts)
                        if best_dist is None or dist < best_dist:
                            best_dist = dist
                            best_line = dpts
                    return best_line

                def render_grid_label(raw_x, raw_y, text, kind, edge):
                    x, y = self._display_xy(raw_x, raw_y)
                    col = (vc if kind == 'v' else hc) if self.same_color.isChecked() else rgba(self.label_color,255)
                    line = nearest_grid_line(kind, raw_x, raw_y)

                    # Find the line point nearest the selected border anchor.
                    ux, uy = (0.0, -1.0) if edge == 'bottom' else (-1.0, 0.0)
                    border_x, border_y = x, y
                    if line and len(line) >= 2:
                        bi = min(range(len(line)), key=lambda i:(line[i][0]-x)**2 + (line[i][1]-y)**2)
                        border_x, border_y = line[bi]

                        # Pick the neighbouring sample that moves INTO the image.
                        candidates = []
                        for delta in (-10, -6, 6, 10):
                            j = max(0, min(len(line)-1, bi+delta))
                            if j == bi:
                                continue
                            vx = line[j][0] - border_x
                            vy = line[j][1] - border_y
                            inward = (border_y - line[j][1]) if edge == 'bottom' else (border_x - line[j][0])
                            candidates.append((inward, vx, vy))
                        if candidates:
                            inward, vx, vy = max(candidates, key=lambda q:q[0])
                            n = math.hypot(vx, vy)
                            if n > 1e-6:
                                ux, uy = vx/n, vy/n
                                # Guarantee the chosen tangent points inward.
                                if edge == 'bottom' and uy > 0:
                                    ux, uy = -ux, -uy
                                elif edge == 'right' and ux > 0:
                                    ux, uy = -ux, -uy

                    # Rotate text parallel to the actual grid line, but keep it readable.
                    angle = -math.degrees(math.atan2(uy, ux))
                    while angle > 90:
                        angle -= 180
                    while angle < -90:
                        angle += 180

                    bb = d.textbbox((0,0), text, font=grid_font, stroke_width=0)
                    bw = max(1, int(math.ceil(bb[2]-bb[0])))
                    bh = max(1, int(math.ceil(bb[3]-bb[1])))
                    font_px = max(10, int(getattr(grid_font, 'size', bh)))
                    pad = max(12, int(font_px*0.20))
                    shadow_px = max(2, int(font_px*0.025))
                    tile = Image.new('RGBA', (bw+pad*2+shadow_px*2, bh+pad*2+shadow_px*2), (0,0,0,0))
                    td = ImageDraw.Draw(tile)
                    ox, oy = pad-bb[0], pad-bb[1]
                    td.text((ox+shadow_px,oy+shadow_px), text, fill=(0,0,0,225), font=grid_font)
                    td.text((ox,oy), text, fill=col, font=grid_font)
                    rot = tile.rotate(angle, expand=True, resample=Image.Resampling.BICUBIC)

                    # Normal direction: Siril places bottom labels to the left of
                    # their line and right-edge labels above their line.
                    nx, ny = uy, -ux
                    if edge == 'bottom' and nx > 0:
                        nx, ny = -nx, -ny
                    if edge == 'right' and ny > 0:
                        nx, ny = -nx, -ny
                    nn = math.hypot(nx, ny)
                    if nn > 1e-6:
                        nx, ny = nx/nn, ny/nn

                    # Exact projected half-size of the rotated rectangle along
                    # the tangent/normal axes. This keeps the whole label inside
                    # the frame and beside, not on top of, the grid line.
                    half_along = abs(ux)*rot.width/2.0 + abs(uy)*rot.height/2.0
                    half_side  = abs(nx)*rot.width/2.0 + abs(ny)*rot.height/2.0
                    along_gap = max(3, int(font_px*0.08))
                    side_gap = max(4, int(font_px*0.10)) + max(1, lw//2)
                    cx = border_x + ux*(half_along + along_gap) + nx*(half_side + side_gap)
                    cy = border_y + uy*(half_along + along_gap) + ny*(half_side + side_gap)

                    px = int(round(cx - rot.width/2.0))
                    py = int(round(cy - rot.height/2.0))
                    safe = max(4, margin)
                    px = max(safe, min(px, max(safe, w-rot.width-safe)))
                    py = max(safe, min(py, max(safe, h-rot.height-safe)))
                    im.alpha_composite(rot, (px,py))

                for item in ra_labels + dec_labels:
                    x,y,text,kind,edge = item
                    render_grid_label(x,y,text,kind,edge)

        if self.labels.isChecked():
            for obj in self.objects:
                rx,ry=float(obj["x"]),float(obj["y"])
                if not (0<=rx<w and 0<=ry<h): continue
                x,y=self._display_xy(rx,ry)
                if obj.get("custom"):
                    mc=rgba(obj.get("marker_color",self.custom_color),255); size=float(obj.get("size",50)); half=size/2; shape=obj.get("shape","Box")
                    if shape=="Box": d.rectangle((x-half,y-half,x+half,y+half),outline=mc,width=2)
                    elif shape=="Circle": d.ellipse((x-half,y-half,x+half,y+half),outline=mc,width=2)
                    elif shape=="Crosshair":
                        d.line((x-half,y,x+half,y),fill=mc,width=2); d.line((x,y-half,x,y+half),fill=mc,width=2)
                if obj.get("type")=="Catalog":
                    style=self.catalog_marker_style.currentText(); auto=obj.get("catalog_marker_px"); size=float(auto) if auto else float(self.catalog_marker_size.get()); size=max(8.0,size); half=size/2
                    mc=rgba(self.label_color,230); mw=max(2,min(12,int(round(self.grid_width.get()/2))))
                    if style in ("Auto (object size)","Circle"): d.ellipse((x-half,y-half,x+half,y+half),outline=mc,width=mw)
                    elif style=="Box": d.rectangle((x-half,y-half,x+half,y+half),outline=mc,width=mw)
                    elif style=="Crosshair":
                        d.line((x-half,y,x+half,y),fill=mc,width=mw); d.line((x,y-half,x,y+half),fill=mc,width=mw)
                if obj.get("type") == "Compass":
                    continue
                name=obj.get("name","").strip()
                if not name: continue
                lf=pil_font(int(self.catalog_font_size.get())) if obj.get("type")=="Catalog" else pil_font(int(obj.get("text_size",self.font_size.get())))
                dobj=dict(obj); dobj["x"]=x; dobj["y"]=y
                tx,ty=self.label_xy(d,dobj,name,lf)
                d.text((tx+1,ty+1),name,fill=(0,0,0,225),font=lf)
                d.text((tx,ty),name,fill=rgba(self.label_color,255),font=lf)
        self.draw_display_compass(d,w,h)
        return im

    def display_base(self):
        return Image.fromarray(self.rgb, "RGB").transpose(Image.Transpose.FLIP_TOP_BOTTOM)

    def refresh(self, fit=False):
        if self.rgb is None:
            return
        try:
            ov = self.display_overlay()
            base = self.display_base().convert("RGBA")
            comp = Image.alpha_composite(base, ov).convert("RGB")
            arr = np.asarray(comp)
            h, w = arr.shape[:2]
            qi = QImage(arr.data, w, h, arr.strides[0], QImage.Format.Format_RGB888).copy()
            self.preview.set_image(QPixmap.fromImage(qi), w, h, fit=fit)
        except Exception as exc:
            self.msg("Preview: " + str(exc))

    # ---------- save ----------
    def output_dir(self):
        if self.original_path is None:
            raise ValueError("Load a FITS first.")
        p = Path(self.out.text().strip())
        if not str(p):
            raise ValueError("Select an output directory.")
        p.mkdir(parents=True, exist_ok=True)
        return p

    def base_stem(self):
        return (self.original_path or self.path).stem

    def save_overlay(self):
        try:
            p = self.output_dir() / f"{self.base_stem()}_overlay.png"
            self.display_overlay().save(p)
            self.results["overlay"] = p
            self.open_overlay.setEnabled(True)
            self.msg("Saved " + p.name)
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def save_overlay_tiff(self):
        try:
            p = self.output_dir() / f"{self.base_stem()}_overlay.tif"
            # RGBA TIFF keeps transparency.
            self.display_overlay().save(p, compression="tiff_lzw")
            self.results["overlay"] = p
            self.open_overlay.setEnabled(True)
            self.msg("Saved " + p.name)
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def composed(self):
        return Image.alpha_composite(
            self.display_base().convert("RGBA"),
            self.display_overlay()
        ).convert("RGB")

    def save_complete(self, ext):
        try:
            p = self.output_dir() / f"{self.base_stem()}_annotated.{ext}"
            im = self.composed()
            if ext == "tif":
                im.save(p, compression="tiff_lzw")
            else:
                im.save(p)
            self.results["complete"] = p
            self.open_complete.setEnabled(True)
            self.msg("Saved " + p.name)
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def save_fits(self):
        try:
            arr = np.moveaxis(np.asarray(self.composed()).astype(np.float32) / 255, -1, 0)
            # composed() is already in Siril visual orientation in v1.8.
            hdr = self.hdr.copy()
            hdr["ROWORDER"] = "BOTTOM-UP"
            hdr["HISTORY"] = "AG Astro Annotator presentation FITS; overlay burned into pixels."
            hdr["HISTORY"] = "Presentation product; original scientific FITS remains unchanged."
            p = self.output_dir() / f"{self.base_stem()}_annotated_presentation.fit"
            fits.PrimaryHDU(arr, header=hdr).writeto(p, overwrite=True)
            self.results["complete"] = p
            self.open_complete.setEnabled(True)
            self.msg("Saved " + p.name)
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))

    def open_result(self, kind):
        p = self.results.get(kind)
        if not p:
            return
        try:
            d = Path(tempfile.gettempdir()) / "AG_Annotator_Open"
            d.mkdir(exist_ok=True)
            q = d / ("overlay.png" if kind == "overlay" else "annotated" + Path(p).suffix)
            shutil.copy2(p, q)
            self.si.cmd("load", str(q))
            self.show()
            self.raise_()
            self.activateWindow()
        except Exception as exc:
            QMessageBox.critical(self, APP, str(exc))


def main():
    app = QApplication.instance()
    own = app is None
    if app is None:
        app = QApplication([])
    w = App()
    w.show()
    if own:
        app.exec()


if __name__ == "__main__":
    main()
